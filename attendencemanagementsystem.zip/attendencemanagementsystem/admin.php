<?php
error_reporting(E_ALL ^ E_NOTICE);


$conn = new mysqli('localhost','root','','blue');  
if($conn->connect_errno){                         
	echo 'Conection Error';
}

if(isset($_POST['submit'])) { 

   $id= $_POST['id'];

   $name = $_POST['name'];

   $email = $_POST['email'];
  

   $phone = $_POST['phone'];
  

   $call1 = $_POST['call1'];
 
	 if(!empty($_POST['s1']) && !empty($_POST['s2']) && !empty($_POST['s3'])) {
		 $a = $_POST['s1'];
  $b = $_POST['s2'];
    $c = $_POST['s3'];
	
	$d=$a.'-'.$b.'-'.$c; 
		 
	 }
		 
		 
	
   $budget = $_POST['budget'];
    $service = "";
    foreach($_POST['service'] as $i) {
        $service.=$i.',';
    }
  $date= date('Y-m-d');
  $image = $_FILES['image']['name'];
  $fileext = pathinfo($image,PATHINFO_EXTENSION);
  if(!($fileext=="jpg" || $fileext=="png" || $fileext=="jpeg" || $fileext=="gif")) {
	  echo "Sorry File type not correct";
	  
  } else {
   if($stmt = $conn->prepare("INSERT INTO contact SET  id=?,fname = ?,email= ?,phone= ?,call1 = ?,budget = ?,service = ?,image=?,date=?,dob=?"))  
   {
	   
	$stmt->bind_param('isssssssss' ,$id,$name,$email,$phone,$call1,$budget,$service,$image,$date,$d); 
	$stmt->execute();  
	   if($stmt->affected_rows==1) {
		   move_uploaded_file($_FILES['image']['tmp_name'],'upload/'.$image);
		   echo "Insert";
	   }
	}
  }
}



?>




<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
	<title>ATTENDENCE MANAGEMENT SYSTEM</title>
	<script>
		function validateForm(){
			let x = document.forms["myForm"]["username"].value;
  			if (x == "") {
   			 alert("Name must be filled out");
   			 return false;
 			 }
		
		let y = document.forms["myForm"]["pwd"].value;
  			if (y == "") {
   			 alert("password must be filled out");
   			 return false;
 			 }
		}
	</script>
</head>
<body>
	<div class="alt-font text-extra-dark-gray font-weight-600 text-center text-lg-left md-width-70 mx-auto mx-lg-0 md-no-margin-bottom sm-width-100" style=" margin-left: 40px; padding: 50px; background-color: green; color: white;">
		 <h1>ATTENDENCE MANAGEMENT SYSTEM</h1>
	</div>

	<div class="col-12 row" style="padding:100px; " >
		<div class="col-8">
			<img src="colleg.jpg" style="width: 100%;">
		</div>
		<div class="col-4">
			<form id="myForm" name="myForm" onsubmit="return validateForm()" method="post" action="login.html">
			<table style="width: 100%; text-align: center; align-content: center; align-self: center; border: 2px solid green; padding-bottom: 50px;">
				<td style="padding: 70px;"><img src="login.png" style="width: 70%"></td>
				<tr>
					<td><label for="username">UserId:</label></td>
					
				</tr>

				<tr>
					<td><input type="text" id="username" name="username"class="form-control" style="width: 50%; margin-left: 100px;"></td>
				</tr>
				<tr>
					<td><label for="pwd">Password:</label></td></tr>
					<tr><td><input type="password" id="pwd" name="pwd" class="form-control"style="width: 50%; margin-left: 100px;"></td>
				</tr>
				
				<tr>
					<td style="padding-top: 10px; "><a href="login.html"><button class="form-control" style="width: 50%; margin-left: 100px; background-color: #4CAF50; color: white;" >Login</button></a></td>
					
				</tr>
			
				<tr>
					<td style="padding-top: 10px;"><a href="register.html"><button class="form-control" style="width: 50%; margin-left: 100px; background-color: #008CBA; color: white;" >Sign Up </button></a></td>
					
				</tr>
				<!-- <tr>
					<td style="padding-top: 10px;">
						<label>Forget Password? <a href="#">Click here</a></label>
					</td>
				</tr>
				<tr>
					<td style="padding-top: 50px;">
						<label><strong>New registration? <a href="#">Click here</a></strong></label>
					</td>
				</tr> -->
			</table>
		</form>
		</div>
	</div>
	</body>
</body>
</html>