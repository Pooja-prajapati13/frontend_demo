<?php


$conn = new mysqli('localhost','root','','blue');  
if($conn->connect_errno){                         
	echo 'Conection Error';
}

?>


<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@7.12.15/dist/sweetalert2.all.min.js"></script>
  <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/sweetalert2@7.12.15/dist/sweetalert2.min.css'></link> 

  <script type="text/javascript">
  	function openalert() {
  		swal({  
		  title: " Are you Sure?",  
		  text: "Confirm once before making attendence!",  
		  type: "warning",  
		  showCancelButton: true,  
		  confirmButtonClass: "btn-danger",  
		  confirmButtonText: " Confirm",  
		  closeOnConfirm: false  
		},  
		function(){  
		  swal("remove it!", "Imaginary file remove it.", "Confirm");  
		});  
  	}
  </script>
	<!-- <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script> -->
	<title></title>
</head>
<body>
	<div class="alt-font text-extra-dark-gray font-weight-600 text-center text-lg-left md-width-70 mx-auto mx-lg-0 md-no-margin-bottom sm-width-100" style=" margin-left: 40px; padding: 50px; background-color: green; color: white;">
		 <h1>ATTENDENCE MANAGEMENT SYSTEM</h1>
	</div>
	<div style="padding: 10px;">
		<a href="admin.html"><button class="form-control" style="width: 10%; float: right; margin-right: 90px;  background-color: #008CBA; color: white;" >Logout</button></a>
	</div>
	<div style="padding: 100px; margin-left: 200px;">
		<button class="form-control" style="width: 21%; float: left; margin-right: 90px;  background-color: #008CBA; color: white;" data-toggle="modal" data-target="#AddNewStudentModal">Add New Student</button>
		<a href="record.html"><button class="form-control" style="width: 11%; float: right; margin-right: 90px;  background-color: #4CAF50; color: white;" >Check Record</button></a>
	</div>
	<div class="modal fade" id="AddNewStudentModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-lg" role="document">
			<div class="modal-content">
		  		<div class="modal-header">
		        	<h5 class="modal-title" id="AddNewStudentModalLabel">Add New Student</h5>
		        	<button type="button" class="close" data-dismiss="modal" aria-label="Close">
		          		<span aria-hidden="true">&times;</span>
		        	</button>
		      	</div>

				<div class="modal-body">
					<div style="padding: 2%;">
						<div class="col-12 row">
							<div class="col-8">
								<input type="text" name="sname" placeholder="Student Name" class="form-control" >
							</div>
							<div class="col-4">
								<input type="number" name="number" placeholder="Student Roll No" class="form-control">
							</div>
						</div>
						<div class="col-12 row" style="padding-top: 20px;">
							<div class="col-4">
								<select id="class" name="class" class="form-control" >
									<option value="">Course</option>
									<option value="">Diploma</option>
									<option value="">B.Tech</option>
									<option value=""> M.Tech</option>
								</select>
							</div>
							<div class="col-4">
								<select id="class" name="class" class="form-control" >
									<option value="">Semester</option>
									<option value="1">I</option>
									<option value="2"> II</option>
								    <option value="3">III </option>
								    <option value="4">IV </option>
								    <option value="5"> V</option>
								    <option value="6"> VI</option>
								    <option value="7"> VII</option>
								    <option value="8"> VIII</option>
								</select>
							</div>
							<div class="col-4">
								<select id="class" name="class" class="form-control" >
					      			<option value="">Branch</option>
									<option value="">Mechanical</option>
									<option value="">Electrical</option>
									<option value="">Civil</option>
									<option value="">CSE</option>
								</select>
							</div>
						</div> 
					</div>
				</div> 
				
				<div class="modal-footer">
					<div class="col-12 row" style="padding-top: 40px;">
						<div class="col-4">
							<label></label>
						</div>
						<div class="col-4">
							<button class="form-control" style="width: 100%;  background-color: #4CAF50; color: white;" >Add Student</button>
						</div>
						<div class="col-4">
							<label></label>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	
	<div class="alt-font text-extra-dark-gray font-weight-600 text-center text-lg-left md-width-70 mx-auto mx-lg-0 md-no-margin-bottom sm-width-100" style=" margin-left: 40px; padding: 50px;">
		<h2>Mark Attendence 16-06-2022</h2><br>
		<table style="width: 80%; margin-left: 120px;" class="table table-bordered table-hover">
			<thead>
				<tr>
				    <th>Sr. No.</th>
				    <th> Name</th>
				    <th>Roll Number</th>
				    <th>Course</th>
				    <th>Semester</th>
				    
				    <th>Branch</th>
				    <th>Attendence</th>
				    
			  </tr>
			</thead>
			<tbody>
				<tr>
				  	<td>1.</td>
				  	<td>Pooja</td>
				  	<td>101</td>
				  	<td>B.Tech</td>
				  	<td>I</td>
				  	<td>CSE</td>
				  	
				  	<td>
				  		<button class="btn btn-sm btn-primary"  data-toggle="modal" data-target="#editModal" onclick="openalert()"><b>P</b></button>
				  		<button class="btn btn-sm btn-danger" data-toggle="modal" data-target="#deleteModal" onclick="openalert()"><b>A</b></button>
			  		</td>
			  	</tr>
			  	<tr>
				  	<td>2.</td>
				  	<td>Vibha</td>
				  	<td>102</td>
				  	<td>B.Tech</td>
				  	<td>I</td>
				  	<td>Civil</td>
				  	
				  	<td>
				  		<button class="btn btn-sm btn-primary"  data-toggle="modal" data-target="#editModal" onclick="openalert()"><b>P</b></button>
				  		<button class="btn btn-sm btn-danger" data-toggle="modal" data-target="#deleteModal" onclick="openalert()"><b>A</b></button>
			  		</td>
			  	</tr>
			  	<tr>
				  	<td>3.</td>
				  	<td>Ritesh</td>
				  	<td>103</td>
				  	<td>B.Tech</td>
				  	<td>I</td>
				  	<td>Electrical</td>
				  	
				  	<td>
				  		<button class="btn btn-sm btn-primary"  data-toggle="modal" data-target="#editModal" onclick="openalert()"><b>P</b></button>
				  		<button class="btn btn-sm btn-danger" data-toggle="modal" data-target="#deleteModal" onclick="openalert()"><b>A</b></button>
			  		</td>
			  	</tr>
			  </tbody>
		</table>
	</div>
</body>
</html>