<?php

$user = 'root';
$pass = '';

$db ='testdbqqqq';

$db = new mysqli('localhost' , $user ,$pass ,$db) or die ("Unable to connect");

?>