<script src="<?php echo $baseurl; ?>jscontroller/login.js"></script>
<div class="" ng-controller="logincontroller" ng-cloak>
<body style="background-color: #19065f;">

	<div class="container"  style="padding: 2%; margin-top: 15%; width: 30%;">
					<fieldset class="border p-2">
                    <legend class="float-none w-auto p-1">Login</legend>
						<input type="email" id="" name="" class="form-control form-control-sm" style="margin-top: 1%;" ng-model="userid" placeholder="Enter email"> <br>
						<input type="" id="" name="" class="form-control form-control-sm" style="margin-top: 1%;" ng-model="password" placeholder="Enter password"><br>
						<button class="btn btn-success btn-sm" type="submit" ng-click="save_login(userid,password)" style="float: right;">Login</button>

                    </fieldset>
				</div>
	
</body>
</div>