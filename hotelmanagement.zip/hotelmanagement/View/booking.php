<?php 
	session_start();
if($_SESSION['id']==''){
	header("location:".$baseurl.'login');
}
 ?>

<script src="<?php echo $baseurl; ?>jscontroller/customer.js"></script>
<div class="content-page" ng-controller="customercontroller" ng-cloak>
	<div class="container-fluid">
		<div class="row content">
			<div class="col-sm-12 form-bg-color">
				<div class="container">
					<h3>Booking Details</h3>
					<hr>
					<table class="table  table-bordered">
						<thead>
							<tr style="background-color: #efefef;">
							<!-- <th style="width: 10%;" rowspan="2">Labels</th> -->
							<th colspan="4" style="width: 60%;">Booking Data</th>
							<th colspan="2" style="width: 30%;" >Booking Dates</th>
							<th style="width: 10%;" rowspan="2">Action</th>
							</tr>
							<tr style="background-color: #efefef;">
						    <th>Guest Name</th>
						    
							<th>Email</th>
							<th>Phone</th>
							<th>Details</th>
							<th>Check-in</th>
							<th>Check-out</th>
							</tr>
						</thead>
						<tbody>
							<tr ng-repeat="mer in allcustomer | toArray">
							<!-- <td><span class="badge bg-info">Approved</span></td> -->
							
										
							<td>{{mer.guestname}}</td>
							<td>{{mer.email}}</td>
							<td>{{mer.phone}}</td>
							<td>{{mer.address}}</td>
							
							<td><span class="badge bg-info  ">{{mer.checkin}}</span></td>
							<td><span class="badge bg-success btn-sm  ">{{mer.checkout}}</span></td>
							<td style="text-align: left; margin-left: 0px;">

							<button class="btn btn-secondary btn-sm" ng-click="detail_customer_modal(mer.slug)"><i class="fa fa-check-circle-o" aria-hidden="true"></i></button>
							<button class="btn btn-danger btn-sm" ng-click="delete_customer_modal(mer.slug)"><i class="fa fa-trash"  aria-hidden="true"></i></button>
							</td>
						</tr>
						</tbody>
						
						<!-- delete modal -->
					<!-- Button trigger modal -->
					
					<div class="modal fade" id="deletecustomer" tabindex="-1" aria-labelledby="deletecustomerLabel" aria-hidden="true">
						  <div class="modal-dialog">
						    <div class="modal-content">
						      <div class="modal-header " style="padding: 1%;">
						        <h5 class="modal-title fs-5" id="deletecustomerLabel">Delete Confirmation</h5>
						        <button type="button" class="btn-close btn-sm" data-bs-dismiss="modal" aria-label="Close"></button>
						      </div>
						      <div class="modal-body">
						        Do you delete you want to delete this record ?
						      </div>
						      <div class="modal-footer" style="padding: 1%;">
						        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
						        <button type="button" class="btn btn-danger btn-sm" ng-click="delete_customer(slugg)">Delete</button>
						      </div>
						    </div>
						  </div>
						</div>
						
						
					</table>

					<div class="modal fade" id="detailcustomer" tabindex="-1" aria-labelledby="detailcustomerLabel" aria-hidden="true">
						  <div class="modal-dialog modal-xl">
						    <div class="modal-content">
						      <div class="modal-header " style="padding: 1%;">
						        <h5 class="modal-title fs-5" id="detailcustomerLabel">Detail Information</h5>
						        <button type="button" class="btn-close btn-sm" data-bs-dismiss="modal" aria-label="Close"></button>
						      </div>
						      <div class="modal-body">
						      	<div class="col-sm-12 row">
						      		<div class="col-sm-4">
						      			<table  style="margin-bottom: 15px;width: 100%;border-collapse: none;">
					                    <tbody >
					                    <tr >
					                    		<tr style="padding: 5px;font-size: 10px;">
					                            <th style="padding: 8px;font-size: 12px;" width="20%">Code</th>
					                            <td style="padding: 8px;font-size: 12px;" width="30%">{{code}}</td>
					                        </tr>
					                        <tr style="padding: 8px;font-size: 12px;">
					                            <th style="padding: 8px;font-size: 12px;" width="20%">Check In </th>
					                            <td style="padding: 8px;font-size: 12px;" width="30%">{{checkin}}</td>
					                        </tr>
					                        <tr style="padding: 8px;font-size: 12px;">
					                            <th style="padding: 8px;font-size: 12px;" width="20%">Child No.</th>
					                            <td style="padding: 8px;font-size: 12px;" width="30%">{{childno}}</td>
					                        </tr>
					                        
					                        <tr style="padding: 8px;font-size: 12px;">
					                            <th style="padding: 8px;font-size: 12px;" width="20%">Room facilities</th>
					                            <td style="padding: 8px;font-size: 12px;" width="30%">{{roomfacilities}}</td>
					                        </tr>
					                        <tr style="padding: 8px;font-size: 12px;">
					                            <th style="padding: 8px;font-size: 12px;" width="20%">Bed Preference </th>
					                            <td style="padding: 8px;font-size: 12px;" width="30%"> 
					                                {{bedpreference}}
					                            </td>
					                        </tr>
					                        <tr style="padding: 8px;font-size: 12px;">
					                            <th style="padding: 8px;font-size: 12px;" width="20%">Email</th>
					                            <td style="padding: 8px;font-size: 12px;" width="30%">{{email}}</td>
					                        </tr>
					                        <tr style="padding: 8px;font-size: 12px;">
					                            <th style="padding: 8px;font-size: 12px;" width="20%">Address</th>
					                            <td style="padding: 8px;font-size: 12px;" width="30%">{{address}}</td>
					                        </tr>
					                        <tr style="padding: 8px;font-size: 12px;">
					                            <th style="padding: 8px;font-size: 12px;" width="20%">State </th>
					                            <td style="padding: 8px;font-size: 12px;" width="30%">{{state}}</td>
					                        </tr>
					                        <tr style="padding: 8px;font-size: 12px;">
					                            <th style="padding: 8px;font-size: 12px;" width="20%">Discount </th>
					                            <td style="padding: 8px;font-size: 12px;" width="30%">{{discount}}</td>
					                        </tr>
					                        <tr style="padding: 8px;font-size: 12px;">
					                            <th style="padding: 8px;font-size: 12px;" width="20%">Net Total </th>
					                            <td style="padding: 8px;font-size: 12px;" width="30%">{{nettotal}}</td>
					                        </tr>
					                        <tr style="padding: 8px;font-size: 12px;">
					                            <th style="padding: 8px;font-size: 12px;" width="20%">Tax Total</th>
					                            <td style="padding: 8px;font-size: 12px;" width="30%">{{taxtotal}}</td>
					                        </tr>
					                    	</tr>

					                        
					                    </tbody>
					                </table>
						      		</div>
						      		<div class="col-sm-4">
						      			<table  style="margin-bottom: 15px;width: 100%;border-collapse: none;">
					                    <tbody >
					                        <tr style="padding: 5px;font-size: 10px;">
					                            <th style="padding: 8px;font-size: 12px;" width="20%">Status</th>
					                            <td style="padding: 8px;font-size: 12px;" width="30%">{{status}}</td>
					                        </tr>
					                        <tr style="padding: 8px;font-size: 12px;">
					                            <th style="padding: 8px;font-size: 12px;" width="20%">Check Out </th>
					                            <td style="padding: 8px;font-size: 12px;" width="30%">{{checkout}}</td>
					                        </tr>
					                        <tr style="padding: 8px;font-size: 12px;">
					                            <th style="padding: 8px;font-size: 12px;" width="20%">Infant No.</th>
					                            <td style="padding: 8px;font-size: 12px;" width="30%">{{infantno}}</td>
					                        </tr>
					                        
					                        <tr style="padding: 8px;font-size: 12px;">
					                            <th style="padding: 8px;font-size: 12px;" width="20%">Your Budget</th>
					                            <td style="padding: 8px;font-size: 12px;" width="30%">{{yourbudget}}</td>
					                        </tr>
					                        <tr style="padding: 8px;font-size: 12px;">
					                            <th style="padding: 8px;font-size: 12px;" width="20%">Guest Name </th>
					                            <td style="padding: 8px;font-size: 12px;" width="30%"> 
					                                {{guestname}}
					                            </td>
					                        </tr>
					                        <tr style="padding: 8px;font-size: 12px;">
					                            <th style="padding: 8px;font-size: 12px;" width="20%">Phone</th>
					                            <td style="padding: 8px;font-size: 12px;" width="30%">{{phone}}</td>
					                        </tr>
					                        <tr style="padding: 8px;font-size: 12px;">
					                            <th style="padding: 8px;font-size: 12px;" width="20%">City</th>
					                            <td style="padding: 8px;font-size: 12px;" width="30%">{{city}}</td>
					                        </tr>
					                        <tr style="padding: 8px;font-size: 12px;">
					                            <th style="padding: 8px;font-size: 12px;" width="20%">Postcode </th>
					                            <td style="padding: 8px;font-size: 12px;" width="30%">{{postcode}}</td>
					                        </tr>
					                        <tr style="padding: 8px;font-size: 12px;">
					                            <th style="padding: 8px;font-size: 12px;" width="20%">Total Amount </th>
					                            <td style="padding: 8px;font-size: 12px;" width="30%">{{totalamount}}</td>
					                        </tr>
					                        <tr style="padding: 8px;font-size: 12px;">
					                            <th style="padding: 8px;font-size: 12px;" width="20%">Tax</th>
					                            <td style="padding: 8px;font-size: 12px;" width="30%">{{tax}}</td>
					                        </tr>
					                        <tr style="padding: 8px;font-size: 12px;">
					                            <th style="padding: 8px;font-size: 12px;" width="20%">Balance</th>
					                            <td style="padding: 8px;font-size: 12px;" width="30%">{{balance}}</td>
					                        </tr>
					                    </tbody>
					                </table>
						      		</div>
						      		<div class="col-sm-4">
						      			<table  style="margin-bottom: 15px;width: 100%;border-collapse: none;">
					                    <tbody>
					                        <tr style="padding: 5px;font-size: 10px;">
					                            <th style="padding: 8px;font-size: 12px;" width="20%">Booking Time</th>
					                            <td style="padding: 8px;font-size: 12px;" width="30%">{{bookingtime}}</td>
					                        </tr>
					                        <tr style="padding: 8px;font-size: 12px;">
					                            <th style="padding: 8px;font-size: 12px;" width="20%">Adult No. </th>
					                            <td style="padding: 8px;font-size: 12px;" width="30%">{{adultno}}</td>
					                        </tr>
					                        <tr style="padding: 8px;font-size: 12px;">
					                            <th style="padding: 8px;font-size: 12px;" width="20%">Room</th>
					                            <td style="padding: 8px;font-size: 12px;" width="30%">{{room}}</td>
					                        </tr>
					                        
					                        <tr style="padding: 8px;font-size: 12px;">
					                            <th style="padding: 8px;font-size: 12px;" width="20%">Meals</th>
					                            <td style="padding: 8px;font-size: 12px;" width="30%">{{meals}}</td>
					                        </tr>
					                        <tr style="padding: 8px;font-size: 12px;">
					                            <th style="padding: 8px;font-size: 12px;" width="20%">Company </th>
					                            <td style="padding: 8px;font-size: 12px;" width="30%"> 
					                               {{company}}  
					                            </td>
					                        </tr>
					                        <tr style="padding: 8px;font-size: 12px;">
					                            <th style="padding: 8px;font-size: 12px;" width="20%">Special Requirement</th>
					                            <td style="padding: 8px;font-size: 12px;" width="30%">{{specialrequirement}}</td>
					                        </tr>
					                        <tr style="padding: 8px;font-size: 12px;">
					                            <th style="padding: 8px;font-size: 12px;" width="20%">Country</th>
					                            <td style="padding: 8px;font-size: 12px;" width="30%">{{country}}</td>
					                        </tr>
					                        <tr style="padding: 8px;font-size: 12px;">
					                            <th style="padding: 8px;font-size: 12px;" width="20%">Room Total</th>
					                            <td style="padding: 8px;font-size: 12px;" width="30%">{{roomtotal}}</td>
					                        </tr>
					                        <tr style="padding: 8px;font-size: 12px;">
					                            <th style="padding: 8px;font-size: 12px;" width="20%">Service Total</th>
					                            <td style="padding: 8px;font-size: 12px;" width="30%">{{servicetotal}}</td>
					                        </tr>
					                        <tr style="padding: 8px;font-size: 12px;">
					                            <th style="padding: 8px;font-size: 12px;" width="20%">Paid </th>
					                            <td style="padding: 8px;font-size: 12px;" width="30%">{{paid}}</td>
					                        </tr>
					                    </tbody>
					                </table>
						      		</div>
						      		
						      	</div>
					                						         
						      </div>
						      <div class="modal-footer" style="padding: 1%;">
						        <!-- <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
						        <button type="button" class="btn btn-danger btn-sm" ng-click="delete_customer(slugg)">Delete</button> -->
						      </div>
						    </div>
						  </div>
						</div>

					<!-- delete modal -->
					<!-- Button trigger modal -->
					
					<div class="modal fade" id="deletecustomer" tabindex="-1" aria-labelledby="deletecustomerLabel" aria-hidden="true">
						  <div class="modal-dialog">
						    <div class="modal-content">
						      <div class="modal-header " style="padding: 1%;">
						        <h5 class="modal-title fs-5" id="deletecustomerLabel">Delete Confirmation</h5>
						        <button type="button" class="btn-close btn-sm" data-bs-dismiss="modal" aria-label="Close"></button>
						      </div>
						      <div class="modal-body">
						        Do you delete you want to delete this record ?
						      </div>
						      <div class="modal-footer" style="padding: 1%;">
						        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
						        <button type="button" class="btn btn-danger btn-sm" ng-click="delete_customer(slugg)">Delete</button>
						      </div>
						    </div>
						  </div>
					</div>
				</div>			
				
				
            </div>

		</div>
	</div>
</div>
						