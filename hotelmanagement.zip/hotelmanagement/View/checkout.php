<?php 
	session_start();
if($_SESSION['id']==''){
	header("location:".$baseurl.'login');
}

$id = $_GET['slug'];
$rdata = $checkout->fetch_registration($id);
$room_orderTotal = $checkout->room_orderTotal($id);

$indate = $rdata['arrival_date'].' '.$rdata['arrival_time']; 
	$outdate = date('Y-m-d H:i:s'); 
$days = $checkout->getdays($indate,$outdate);
print_r($rdata);
 ?>

<script src="<?php echo $baseurl; ?>jscontroller/checkout.js"></script>
<div class="content-page" ng-controller="checkoutcontroller" ng-cloak>
	<div class="container-fluid">
		<div class="row content">
				
			<div class="col-12 row">
				<div class="col-6">
					<h3 style="padding: 1%; margin-top: 1%;">Room Check In</h3>

				<div class="container"  style="padding: 2%; margin-top: 2%;">
					<fieldset class="border p-2">
                    <legend class="float-none w-auto p-1">Room No. <?php echo $rdata['room_no'] ?> (AC)</legend>
						<div class="col-12 row p-2">
							<div class="customer col-6">
								<label>Registration Number</label>
								<input type="" id="" name="" class="form-control form-control-sm" value="<?php echo $rdata['registeration_no'] ?>" style="margin-top: 1%;" ng-model=""> <br>
								
								<label>Checkout Date</label>
								<input type="date" id="" name="" class="form-control form-control-sm" style="margin-top: 1%;" ng-model="checkout_date" value="<?php echo date('d-m-Y') ?>" > <br><br>	
							</div>	
							<div class="customer col-6">
								<label>Invoice No.</label>
								<input type="" id="" name="" class="form-control form-control-sm" style="margin-top: 1%;" ng-model="invoice_no" ><br>
								<label>Checkout Time</label>
								<input type="time" id="" name="" class="form-control form-control-sm" style="margin-top: 1%;" ng-model="checkout_time">
							</div>
							<div>
								<label>Payable Amount</label>
								<input type="" id="" name="" class="form-control form-control-sm" style="margin-top: 1%;" ng-model="payable_amount"> <br>
							</div>
							<div class="table-responsive">
						<table class="table table-bordered" >
						<thead>
							<tr style="background-color: #efefef;">
								<th>SN</th>
								<th>Pay Type</th>
								<th>Amount</th>
								<th>Remark</th>
								<th>Action</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td></td>
								<td><select class="form-control form-control-sm" ng-model="pay_type">
	        					<option>select</option>
								<option>Cash</option>
								<option>Credit</option>
								<option>Phone Pay</option>
								<option>Check</option>
								<option>Google Pay</option>
								<option>Booking.com Paid</option>
	     						 </select></td>
								<td><input type="number" id="" name="" min="0" max="100000000000" class="form-control form-control-sm" ng-model="amount"></td>
								<td><input type=""  name=""  class="form-control form-control-sm"> </td>
								<td><button class="btn btn-danger btn-sm">Add</button></td>	
							</tr>
							<tr style="background-color: #efefef;">
							    <td colspan="2">Total </td>
							    <td></td>
							    <td></td>
								<td></td>
							</tr>
							<tr style="background-color: #efefef;">
							    <td colspan="2">Current balance</td>
							    <td></td>
							    <td></td>
								<td></td>
							</tr>
						</tbody>
					</table>
					<div>
						<label>Remark</label>
						<input type="" id="" name="" class="form-control form-control-sm" style="margin-top: 1%;" ng-model="remark"><br>
					</div>
					<button class="btn btn-success btn-sm">Check out</button>
					</div>		
						</div>
                    </fieldset>
				</div>	
				</div>
				<div class="col-6">
					<h3 style="padding: 1%; margin-top: 1%;">Booking Details</h3>

				<div class="container"  style="padding: 2%; margin-top: 2%;">
					<fieldset class="border p-2">
                    <legend class="float-none w-auto p-1">Booking Details</legend>
						<div class="col-12 row p-2">
							
							
					<div class="table-responsive">
					<table class="table table-bordered" >
						
						<tbody style="background-color: #efefef;">
							<tr>
								<td>Arrived Date</td>
								<td><?php echo $rdata['arrival_date'] ?></td>
							</tr>
							<tr>
								<td>Arrived Time</td>
								<td><?php echo $rdata['arrival_time'] ?></td>
							</tr><tr>
								<td>Stay</td>
								<td><?php echo $days ?></td>
							</tr><tr>
								<td>Occupy Type</td>
								<td><?php echo $rdata['occupy'] ?></td>
							</tr><tr>
								<td>Room Rent</td>
								<td><?php echo $rdata['room_rent'] * $days  ?></td>
							</tr>
							<tr>
								<td>Room Advance</td>
								<td><?php echo $rdata['advance'] ?></td>
							</tr>
							<tr>
								<td>Order Amount</td>
								<td><?php print_r($room_orderTotal) ?></td>
							</tr>
							
							<tr>
								<td>Total Bill Amt</td>
								<td><?php echo (($rdata['room_rent'] * $days) + $room_orderTotal);  ?></td>
							</tr>
							
							<tr>
								<td>Balance Amt</td>
								<td><?php echo (($rdata['room_rent'] * $days) + $room_orderTotal) - $rdata['advance'];  ?></td>
							</tr>
						</tbody>
					</table>
					
					<button class="btn btn-success btn-sm">Print</button>
					</div>		
						</div>
                    </fieldset>
				</div>
				</div>
			</div>
		</div>
	</div>
</div>


<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<!-- <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
 -->
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script> -->
<script type="text/javascript">
	$(function () {
  $('select').each(function () {
    $(this).select2({
      theme: 'bootstrap4',
      width: 'style',
      placeholder: $(this).attr('placeholder'),
      allowClear: Boolean($(this).data('allow-clear')),
    });
  });
});
</script>

<!-- <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script> -->
<!-- </html> -->