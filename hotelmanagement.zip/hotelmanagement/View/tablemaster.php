<?php 
	session_start();
if($_SESSION['id']==''){
	header("location:".$baseurl.'login');
}
 ?>

<script src="<?php echo $baseurl; ?>jscontroller/tablemaster.js"></script>
<div class="content-page" ng-controller="tablemastercontroller" ng-cloak>
	<div class="container-fluid">
		<div class="row content">

			<div class="col-sm-12 form-bg-color" style="">
				<h3 style="padding: 1%; margin-top: 1%;">Add New Master Table</h3>
				
                <div class="container"  style="padding: 2%; margin-top: 2%;">
					<fieldset class="border p-2">
                    <legend class="float-none w-auto p-1"></legend>
						<div class="col-12 row p-2">
							<div class="customer col-3">
								<label>Table Category</label><br>
								<select class="form-control form-control-sm"   style="margin-top: 1%;" ng-model="table_category">
	        					<option></option>
								<option>table</option>
	     						 </select><br>	
							</div>	
							<div class="customer col-3">
								<label>Table Code</label><br>
								<input type="" id="" name="" class="form-control form-control-sm" style="margin-top: 1%;" ng-model="table_code" ><br>
								
								<button class="btn btn-success btn-sm" ng-click="save_table_master(table_category, table_code, table_name, table_status )" style="float: right;">Save</button>
							</div>
							<div class="customer col-3">
								<label>Table Name</label><br>
								<input type="" id="" name="" class="form-control form-control-sm" style="margin-top: 1%;" ng-model="table_name" > <br>

								
								
							</div>
							<div class="customer col-3">
								<label>Status</label><br>
								<select class="form-control form-control-sm"   style="margin-top: 1%;" ng-model="table_status">
	        					<option></option>
	        					<option>Enable</option>
								<option>Disable</option>
	     						</select><br>

								
								
							</div>

						</div>
                    </fieldset>
				</div>
				
				
				<!-- Modal -->
				
				
			</div>
				

		</div>
	</div>
</div>


<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<!-- <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
 -->
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script> -->
<script type="text/javascript">
	$(function () {
  $('select').each(function () {
    $(this).select2({
      theme: 'bootstrap4',
      width: 'style',
      placeholder: $(this).attr('placeholder'),
      allowClear: Boolean($(this).data('allow-clear')),
    });
  });
});
</script>

<!-- <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script> -->
<!-- </html> -->