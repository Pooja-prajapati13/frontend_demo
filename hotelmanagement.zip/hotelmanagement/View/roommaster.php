

<script src="<?php echo $baseurl; ?>jscontroller/roommaster.js"></script>
<div class="content-page" ng-controller="roommastercontroller" ng-cloak>
	<div class="container-fluid">
		<div class="row content">

			<div class="col-sm-12 form-bg-color" style="">
				<h3 style="padding: 1%; margin-top: 1%;">Add New Master Room</h3>
				
                <div class="container"  style="padding: 2%; margin-top: 2%;">
					<fieldset class="border p-2">
                    <legend class="float-none w-auto p-1">Add Room</legend>
						<div class="col-12 row p-2">
							<div class="customer col-4">
								<label>Room Category</label><br>
								<select class="form-control form-control-sm"   style="margin-top: 1%;" ng-model="roomcategory">
	        					<option></option>
								<option>Deluxe Room</option>
								<option>Suit Room</option>
	     						 </select> <br>
								
								<label>Rent/Day</label><br>
								<input type=""class="form-control form-control-sm" style="margin-top: 1%;" ng-model="rent">
								 <br>	
							</div>	
							<div class="customer col-4">
								<label>Room Type</label><br>
								<select class="form-control form-control-sm"   style="margin-top: 1%;" ng-model="roomtype">
	        					<option></option>
								<option>AC</option>
								<option>Non Ac</option>
	     						 </select><br>
								<label>Status</label><br>
								<select class="form-control form-control-sm"   style="margin-top: 1%;" ng-model="status">
	        					<option></option>
								<option>Enable</option>
								<option>Disable</option>
	     						 </select><br>
								<button class="btn btn-success btn-sm" ng-click="save_room(roomcategory, roomtype, roomno, rent, status)" style="float: right;">Save</button>
							</div>
							<div class="customer col-4">
								<label>Room No. </label><br>
								<input type="" id="" name=""class="form-control form-control-sm" style="margin-top: 1%;" ng-model="roomno"> <br>

								
								
							</div>


						</div>
                    </fieldset>
                    
				</div>
				<div class="container"  style="padding: 2%; margin-top: 2%;">
					
						<div class="table-responsive">
						<table class="table table-bordered" >
						<thead>
							<tr style="background-color: #efefef;">
								<th>SN</th>
								<th>Room Category</th>
								<th>Room type</th>
								<th>Room No.</th>
								<th>Rent/Day</th>
								<th>Status</th>
								<th>Action</th>
							</tr>
						</thead>
						<tbody>
							<tr ng-repeat="room in allroom | toArray">
								<td>#</td>
								<td>{{room.roomcategory}}</td>
								<td>{{room.roomtype}}</td>
								<td>{{room.roomno}}</td>
								<td>{{room.rent}}</td>
								<td>{{room.status}}</td>
								<td><button type="button" class="btn btn-primary btn-sm" ng-click="update_room_modal(room.id)" ><i class="fa fa-pencil-square" aria-hidden="true"></i></button></td>
								
							</tr>
						</tbody>
					</table>
					</div>		
					
				</div>
				
				<!-- Modal -->
				

				<!-- Modal -->
				<div class="modal fade" id="updateroom" tabindex="-1" aria-labelledby="updateroomlabel" aria-hidden="true">
				  <div class="modal-dialog modal-xl">
				    <div class="modal-content">
				      <div class="modal-header">
				        <h5 class="modal-title fs-5" id="updateroomlabel">Edit</h5>
				        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				      </div>
				      <div class="modal-body">
				        <div class="col-12 row p-2">
							<div class="customer col-4">
								<label>Room Category</label><br>
								<select class="form-control form-control-sm"   style="margin-top: 1%;" ng-model="update_roomcategory">
	        					<option></option>
								<option>Deluxe Room</option>
								<option>Suit Room</option>
	     						 </select> <br>
								
								<label>Rent/Day</label><br>
								<input type=""class="form-control form-control-sm" style="margin-top: 1%;" ng-model="update_rent">
								 <br>	
							</div>	
							<div class="customer col-4">
								<label>Room Type</label><br>
								<select class="form-control form-control-sm"   style="margin-top: 1%;" ng-model="update_roomtype">
	        					<option></option>
								<option>AC</option>
								<option>Non Ac</option>
	     						 </select><br>
								<label>Status</label><br>
								<select class="form-control form-control-sm"   style="margin-top: 1%;" ng-model="update_status">
	        					<option></option>
								<option>Enable</option>
								<option>Disable</option>
	     						 </select><br>
								
							</div>
							<div class="customer col-4">
								<label>Room No. </label><br>
								<input type="" id="" name=""class="form-control form-control-sm" style="margin-top: 1%;" ng-model="update_roomno"> <br>

								
								
							</div>


						</div>
				      </div>
				      <div class="modal-footer">
				        <button type="button" class="btn btn-light mr-1" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary btn-sm" id="btn-update-event" ng-click="update_room(id,update_roomcategory, update_roomtype, update_roomno, update_rent, update_status)">Update</button>
				      </div>
				    </div>
				  </div>
				</div>
				
			</div>
				

		</div>
	</div>
</div>


<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<!-- <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
 -->
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script> -->
<script type="text/javascript">
	$(function () {
  $('select').each(function () {
    $(this).select2({
      theme: 'bootstrap4',
      width: 'style',
      placeholder: $(this).attr('placeholder'),
      allowClear: Boolean($(this).data('allow-clear')),
    });
  });
});
</script>

<!-- <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script> -->
<!-- </html> -->