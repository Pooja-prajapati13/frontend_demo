<?php 
	session_start();
if($_SESSION['id']==''){
	header("location:".$baseurl.'login');
}

//$data=$roomorder->fetch_registration_number($id);
 ?>

<?php
$slug=$_GET['slug'];
?>
<script type="text/javascript">
	var slug='<?php echo $slug?>';
</script>



<script src="<?php echo $baseurl; ?>jscontroller/roomorder.js"></script>
<div class="content-page" ng-controller="roomordercontroller" ng-cloak>
	<div class="container-fluid">
		<div class="row content">

			<div class="col-sm-12 form-bg-color" style="">
				<h3 style="padding: 1%; margin-top: 1%;">Room No.  Order</h3>

				
                <div class="container"  style="padding: 2%; margin-top: 2%;">
					<fieldset class="border p-2">
                    <legend class="float-none w-auto p-1">Room No.  (AC)</legend>
						<div class="col-12 row p-2">
							<div class=" col-2">
								<label>Service</label><br>
								<select class="form-control form-control-sm"   style="margin-top: 1%;" ng-model="service">
	        					<option>123</option>
								<option>Indian</option>
								<option>Other Country</option>
	     						 </select> <br>
							</div>	
							<div class="col-2">
								<label>Rate</label><br>
								<input type="" id="" name="" class="form-control form-control-sm" style="margin-top: 1%;" ng-model="rate" ><br>
							</div>
							<div class="col-2">
								<label>Quantity</label><br>
								<input type="number" id="quantity" name="quantity" min="1" max="1000" class="form-control form-control-sm" style="margin-top: 1%;" ng-model="quantity"> <br>
							</div>
							<div class=" col-2">
								<label>Total</label><br>
								<input type="" id="" name="" class="form-control form-control-sm" style="margin-top: 1%;" ng-model="total"> <br>
							</div>	
							<div class="col-2">
								<label>Is Free</label><br>
								<input type="checkbox" id="" name="" value="" ng-model="is_free">
  								<label for=""> Is Free</label><br>
							</div>
							<div class="col-2">
								<label></label><br>
								<button class="btn btn-success btn-sm" ng-click="add_order(service,rate,quantity,total,is_free)" style="">Add</button> <br>
							</div>		
						</div>
                    </fieldset>
				</div>
				<div class="container" style="padding: 2%; margin-top: 2%;" >
                    <fieldset class="border p-2">
                    
					<div class="col-12 row p-2">
						<div class="table-responsive">
						<table class="table table-bordered" >
						<thead>
							<tr style="background-color: #efefef;">
								<th>SN</th>
								<th>Service Name</th>
								<th>Rate</th>
								<th>Quantity</th>
								<th>Is Free</th>
								<th>Total</th>
								<th>Is Cancelled</th>
								
							</tr>
						</thead>
						<tbody>
							<tr ng-repeat="mea in allorder | toArray">
								<td>{{mea.}}</td>
								<td>{{mea.service}}</td>
								<td>{{mea.rate}}</td>
								<td>{{mea.quantity}}</td>
								<td>{{mea.total}}</td>
								<td>{{mea.is_free}}</td>
								<td>{{mea.}}</td>
							</tr>
						</tbody>
					</table>
					</div>		
					</div>
					
				
                    </fieldset>

				</div>
				
				<!-- Modal -->
				<div class="modal fade" id="addmember" tabindex="-1" aria-labelledby="addmember1" aria-hidden="true">
					<div class="modal-dialog">
						<div class="modal-content">
							<div class="modal-header">
								<h1 class="modal-title fs-5" id="addmember1">Add Room</h1>
								 
							</div>
							<div class="modal-body" >

								<div class="col-12">
									<input type="" name="" class="form-control form-control-sm" ng-model="name" placeholder="Enter Guest Mobile"><br>
									<input type="" name="" class="form-control form-control-sm " ng-model="name" placeholder="Relationship"><br>
									<input type="" name="" class="form-control form-control-sm" ng-model="name" placeholder="Guest Name"><br>
									<select class="form-control form-control-sm">
			        					<option>Guest Id Type</option>
										<option>Indian</option>
										<option>Other Country</option>
			     					</select><br>
									<input type="" name="" class="form-control form-control-sm" ng-model="name" placeholder="Guest Id"><br>

									

									
										<label>Document Front</label>
										<input type="file" id="file" name="file" class="form-control form-control-sm" ng-model="file" accept="image/*" ngf-select  ngf-max-size="100MB" ngf-model-invalid="errorFile"><br>

									
									
										<label>Document Back</label>
										<input type="file" id="file" name="file" class="form-control form-control-sm" ng-model="file" accept="image/*" ngf-select  ngf-max-size="100MB" ngf-model-invalid="errorFile"><br>

										<label>Signature</label>
										<input type="file" id="file" name="file" class="form-control form-control-sm" ng-model="file" accept="image/*" ngf-select  ngf-max-size="100MB" ngf-model-invalid="errorFile">
									
									
								</div>
							</div>
							<div class="modal-footer">
								<button type="button" class="btn btn-default btn-sm" data-bs-dismiss="modal"></button>
								<button type="button" class="btn btn-primary btn-sm" ng-click="add_member(name, mobileno, email, address, designation, workexperience, joiningdate, salary)">Save</button>
							</div>
						</div>
					</div>
				</div>
				
			</div>
				

		</div>
	</div>
</div>


<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<!-- <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
 -->
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script> -->
<script type="text/javascript">
	$(function () {
  $('select').each(function () {
    $(this).select2({
      theme: 'bootstrap4',
      width: 'style',
      placeholder: $(this).attr('placeholder'),
      allowClear: Boolean($(this).data('allow-clear')),
    });
  });
});
</script>

<!-- <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script> -->
<!-- </html> -->