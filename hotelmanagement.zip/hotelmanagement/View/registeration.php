<?php 
	session_start();
if($_SESSION['id']==''){
	header("location:".$baseurl.'login');
}


 ?>

<script src="<?php echo $baseurl; ?>jscontroller/registeration.js"></script>
<div class="content-page" ng-controller="registerationcontroller" ng-cloak>
	<div class="container-fluid">
		<div class="row content">

			<div class="col-sm-12 form-bg-color" style="">
				<h3 style="padding: 1%; margin-top: 1%;">Room Booking</h3>
				
                <div class="container"  style="padding: 2%; margin-top: 2%;">
					<fieldset class="border p-2">
                    <legend class="float-none w-auto p-1">Information</legend>
						<div class="col-12 row p-2">
							<div class="customer col-4">
								<label>Registration Number</label><br>
								<input type="" id="" name="" class="form-control form-control-sm" style="margin-top: 1%;" ng-model="registeration_no"> <br>
								
								<label>Occupy Type</label><br>
								<select class="form-control form-control-sm"   style="margin-top: 1%;" ng-model="occupy">
	        					<option></option>
								<option>Booking</option>
								<option>Walk In</option>
								<option>Self Booking</option>
								<option>Booking.com</option>
	     						 </select> <br>


							<label>Company GST</label><br>
								<input type=""  name="" class="form-control form-control-sm" style="margin-top: 1%;" ng-model="company_gst"> <br>


									<label>Room Rent</label><br>
									<input type="" class="form-control form-control-sm" style="margin-top: 1%;" ng-model="room_rent"><br>
									
									<label>Room No</label><br>
									<select class="form-control form-control-sm"   style="margin-top: 1%;" ng-model="room_no">
		        					<option></option>
									<option>301</option>
									<option>302</option>
									<option>303</option>
									<option>304</option>
									<option>305</option>
									<option>306</option>
									<option>307</option>
									<option>308</option>
									<option>309</option>
									<option>310</option>
									</select><br> 
									
								
									<label>Permanent Address </label><br>
									<textarea class="form-control form-control-sm" style="margin-top: 1%;" ng-model="permanent_address"> </textarea><br>
									
									
									
									     						
								
							</div>	
							<div class="customer col-4">
								<label>Arrival Date</label><br>
								<input type="date" id="" name="" class="form-control form-control-sm" style="margin-top: 1%;" ng-model="arrival_date" value="<?php echo date('Y-m-d'); ?>" ><br>
								<label>Guest Name</label><br>
								<input type="text" id="" name="" class="form-control form-control-sm" style="margin-top: 1%;" ng-model="guest_name"> <br>
								<label>No. of Persons</label><br>
									<input type="number" min="0" max="10000" class="form-control form-control-sm" style="margin-top: 1%;" ng-model="no_of_person"><br>
									
								
									<label>Advance</label><br>
									<input type="number" min="0" max="1000000" class="form-control form-control-sm" style="margin-top: 1%;" ng-model="advance"><br>
									<label>Guest Id</label><br>
							<input type="" id="" name="" class="form-control form-control-sm" style="margin-top: 1%;" ng-model="guest_id"> <br>
							<label>Nationality</label><br>
								<select class="form-control form-control-sm"   style="margin-top: 1%;" ng-model="nationality">
	        					<option></option>
								<option>Indian</option>
								<option>Other Country</option>
	     						 </select>
							</div>
							<div class="customer col-4">
								<label>Arrival Time </label><br>
								<input type="time" id="quantity" name="quantity" min="1" max="5" class="form-control form-control-sm" style="margin-top: 1%;" ng-model="arrival_time"> <br>
								<label>Company Name</label>
								<input type="" name="" class="form-control form-control-sm" style="margin-top: 1%;" ng-model="company_name"><br>
								<label>Mobile</label><br>
								<input type="" name=""  class="form-control form-control-sm" style="margin-top: 1%;" ng-model="mobile"> <br>
								
								<label>Reference</label><br>
								<input type=""  name=""  class="form-control form-control-sm" style="margin-top: 1%;" ng-model="reference"> <br>
								<label>Document</label><br>
								<input type="file" id="file" name="file" class="form-control form-control-sm" ng-model="file" accept="image/*" ngf-select  ngf-max-size="100MB" ngf-model-invalid="errorFile"><br>
								<button class="btn btn-success btn-sm" ng-click="check_in(registeration_no, arrival_date, arrival_time, occupy, guest_name, company_name, company_gst, no_of_person, mobile, room_rent, advance, reference, room_no, file, guest_id, permanent_address, nationality)" style="float: right; margin-top: 20%;">Check In</button>
								
							</div>		
						</div>
                    </fieldset>
				</div>
				<!-- <div class="container" style="padding: 2%; margin-top: 2%;" >
                    <fieldset class="border p-2">
                    <legend class="float-none w-auto p-1">
                    	<button type="button" class="btn btn-primary btn-sm" data-bs-target="#addmember"  data-bs-toggle="modal">
						Add Guest
					</button>
                    </legend>
					<div class="col-12 row p-2">
						<div class="table-responsive">
						<table class="table table-bordered" >
						<thead>
							<tr style="background-color: #efefef;">
								<th>SN</th>
								<th>Guest Name</th>
								<th>Relationship</th>
								<th>Mobile</th>
								<th>Guest Id</th>
								<th>Guest Document Type</th>
								<th>Document Front</th>
								<th>Document Back</th>
								<th>Action</th>
							</tr>
						</thead>
						<tbody>
							<tr ng-repeat="mem in allmembers | toArray">
								<td>{{mem.name}}</td>
								<td>{{mem.mobile}}</td>
								<td>{{mem.email}}</td>
								<td>{{mem.address}}</td>
								<td>{{mem.designation}}</td>
								<td>{{mem.workexperience}}</td>
								<td>{{mem.joiningdate}}</td>
								<td>{{mem.salary}}</td>
								<td></td>
							</tr>
						</tbody>
					</table>
					</div>		
					</div>
					
					
					
				
                    </fieldset>

				</div> -->
				
				<!-- Modal -->
				<div class="modal fade" id="addmember" tabindex="-1" aria-labelledby="addmember1" aria-hidden="true">
					<div class="modal-dialog">
						<div class="modal-content">
							<div class="modal-header">
								<h1 class="modal-title fs-5" id="addmember1">Add Room</h1>
								 
							</div>
							<div class="modal-body" >

								<div class="col-12">
									<input type="" name="" class="form-control form-control-sm" ng-model="name" placeholder="Guest Name"><br>
									<input type="" name="" class="form-control form-control-sm " ng-model="name" placeholder="Relationship"><br>
									<input type="" name="" class="form-control form-control-sm" ng-model="name" placeholder="Enter Guest Mobile "><br>
									<select class="form-control form-control-sm">
			        					<option>Guest Id Type</option>
										<option>Indian</option>
										<option>Other Country</option>
			     					</select><br>
									<input type="" name="" class="form-control form-control-sm" ng-model="name" placeholder="Guest Id"><br>

									

									
										<label>Document Front</label>
										<input type="file" id="file" name="file" class="form-control form-control-sm" ng-model="file" accept="image/*" ngf-select  ngf-max-size="100MB" ngf-model-invalid="errorFile"><br>

									
									
										<label>Document Back</label>
										<input type="file" id="file" name="file" class="form-control form-control-sm" ng-model="file" accept="image/*" ngf-select  ngf-max-size="100MB" ngf-model-invalid="errorFile"><br>

										<label>Signature</label>
										<input type="file" id="file" name="file" class="form-control form-control-sm" ng-model="file" accept="image/*" ngf-select  ngf-max-size="100MB" ngf-model-invalid="errorFile">
									
									
								</div>
							</div>
							<div class="modal-footer">
								<button type="button" class="btn btn-default btn-sm" data-bs-dismiss="modal"></button>
								<button type="button" class="btn btn-primary btn-sm" ng-click="add_member(name, mobileno, email, address, designation, workexperience, joiningdate, salary)">Save</button>
							</div>
						</div>
					</div>
				</div>
				
			</div>
				

		</div>
	</div>
</div>


<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<!-- <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
 -->
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script> -->
<script type="text/javascript">
	$(function () {
  $('select').each(function () {
    $(this).select2({
      theme: 'bootstrap4',
      width: 'style',
      placeholder: $(this).attr('placeholder'),
      allowClear: Boolean($(this).data('allow-clear')),
    });
  });
});
</script>

<!-- <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script> -->
<!-- </html> -->