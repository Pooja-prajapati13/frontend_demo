<?php 
	session_start();
if($_SESSION['id']==''){
	header("location:".$baseurl.'login');
}
 ?>

<script src="<?php echo $baseurl; ?>jscontroller/menuitemmaster.js"></script>
<div class="content-page" ng-controller="menuitemmastercontroller" ng-cloak>
	<div class="container-fluid">
		<div class="row content">

			<div class="col-sm-12 form-bg-color" style="">
				<h3 style="padding: 1%; margin-top: 1%;">Add New Menu Item Master</h3>
				
                <div class="container"  style="padding: 2%; margin-top: 2%;">
					<fieldset class="border p-2">
                    <legend class="float-none w-auto p-1"></legend>
						<div class="col-12 row p-2">
							<div class="customer col-3">
								<label>Product code</label><br>
								<input type="" id="" name="" class="form-control form-control-sm" style="margin-top: 1%;" ng-model="product_code" > <br>	
								<label>Veg/Non-veg</label><br>
								<select class="form-control form-control-sm"   style="margin-top: 1%;" ng-model="veg_nonveg">
	        					<option></option>
								<option>veg</option>
								<option>nonveg</option>
	     						 </select> <br>
								<label>Status</label><br>
								<select class="form-control form-control-sm"   style="margin-top: 1%;" ng-model="menuitem_status">
	        					<option></option>
								<option>Enable</option>
								<option>Disable</option>
	     						 </select> <br>
							</div>	
							<div class="customer col-3">
								<label>Product Name</label><br>
								<input type="" id="" name="" class="form-control form-control-sm" style="margin-top: 1%;" ng-model="product_name"><br>
	     						 <label>MRP</label><br>
								<input type="" id="" name="" class="form-control form-control-sm" style="margin-top: 1%;" ng-model="mrp" > <br><br>
								<!-- <label>Countable Stock</label><br> -->
								<input type="checkbox" id="" name="" value="" ng-model="countable_stock">
  								<label for=""> Countable Stock</label><br>
								
								<!-- <button class="btn btn-success btn-sm" ng-click="save_menu_category(menu_category_name, menu_category_status)" style="float: right;">Save</button> -->
							</div>
							<div class="customer col-3">
								<label>Unit Name </label><br>
								<select class="form-control form-control-sm"   style="margin-top: 1%;" ng-model="unit_name">
	        					<option></option>
								<option>ghhj</option>
	     						 </select><br>
								<label>In Stocks</label><br>
								<input type="" id="" name="" class="form-control form-control-sm" style="margin-top: 1%;" ng-model="in_stock"><br><br>
								<button class="btn btn-success btn-sm" ng-click="save_menu_item(product_code, product_name, unit_name, category, veg_nonveg, mrp, in_stock, min_stock, menuitem_status, countable_stock)" style="float: right;">Save</button>
								
							</div>
							<div class="customer col-3">
								<label>Category</label><br>
								<select class="form-control form-control-sm"   style="margin-top: 1%;" ng-model="category">
	        					<option></option>
								<option>ghhj</option>
	     						 </select><br>
								<label>Min Stocks</label><br>
								<input type="" id="" name="" class="form-control form-control-sm" style="margin-top: 1%;" ng-model="min_stock" > <br>
								
								
							</div>


						</div>
                    </fieldset>
				</div>
				
				
				<!-- Modal -->
				
				
			</div>
				

		</div>
	</div>
</div>


<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<!-- <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
 -->
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script> -->
<script type="text/javascript">
	$(function () {
  $('select').each(function () {
    $(this).select2({
      theme: 'bootstrap4',
      width: 'style',
      placeholder: $(this).attr('placeholder'),
      allowClear: Boolean($(this).data('allow-clear')),
    });
  });
});
</script>

<!-- <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script> -->
<!-- </html> -->