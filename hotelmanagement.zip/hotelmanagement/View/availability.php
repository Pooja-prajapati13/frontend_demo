<?php 
	session_start();
if($_SESSION['id']==''){
	header("location:".$baseurl.'login');
}
 ?>



<div class="content-page">
	<div class="container-fluid">
		<div class="row content">
			<div class="col-sm-12 form-bg-color">
				<div class="container" >
					<h3>Availability</h3>
					
					<div class="container-fluid"><br>
						<div class="col-12 row">
							<div class="col-3">
								<label>Select Room Category :</label>
							</div>
							<div class="col-9 row">
								<select class="form-control form-control-sm" style="width: 50%;">
							<option value=""></option>
							<option value="">Standard Room</option>
							<option value="">Superior Room</option>
							<option value="">Junior Suite</option>
							<option value="">Grand Superior Room</option>
							<option value="">Deluxe Room</option>
							<option value="">Family Special</option>
							<option value="">Premium Room</option>
						</select>
							</div>
							<div>
								<button class="btn btn-success btn-sm" style="float: right;">Total Vacant </button>
							</div>
						</div>
						<hr><br>
						<table class="table table-bordered">
						<tr style="background-color: #efefef;">
							<th>RoomId</th>
							<th>RoomNo.</th>
							<th>RoomType</th>
							<th>IsAvailable</th>
							<th>Description</th>
							
						</tr>
						<tr>
							<td>1</td>
							<td>101</td>
							<td>Standard Room</td>
							<td>Yes</td>
							<td >
							 AC
						    </td>
						</tr>
						<tr>
							<td>2</td>
							<td>102</td>
							<td>Superior Room</td>
							<td>Yes</td>
							<td>Non-Ac</td>
						</tr>
						<tr>
							<td>3</td>
							<td>103</td>
							<td>Junior Suite</td>
							<td>Yes</td>
							<td>AC</td>
						</tr>
					</table>
					</div>
				

				</div>
			</div>
		</div>
	</div>
</div>