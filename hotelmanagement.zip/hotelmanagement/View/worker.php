<?php 
	session_start();
if($_SESSION['id']==''){
	header("location:".$baseurl.'login');
}
 ?>

<script src="<?php echo $baseurl; ?>jscontroller/worker.js"></script>
<div class="content-page" ng-controller="workercontroller" ng-cloak>
	<div class="container-fluid">
		<div class="row content">
			<div class="col-sm-12 form-bg-color" >

				<div class="container">
					<h3>Hotel Staff</h3>
					<button type="button" class="btn btn-primary btn-sm" data-bs-target="#addmember"  data-bs-toggle="modal" style="float:right;">
						Add Member
					</button>

					<br>
					<hr>
					<div class="table-responsive">
						<table class="table table-bordered" >
						<thead>
							<tr style="background-color: #efefef;">
								<th>Name</th>
								<th>MobileNo.</th>
								<th>E-mail</th>
								<th>Address</th>
								<th>Designation</th>
								<th>Work Experience</th>
								<th>Joining Date</th>
								<th>Salary (in Rs.)</th>
							</tr>
						</thead>
						<tbody>
							<tr ng-repeat="mem in allmembers | toArray">
								<td>{{mem.name}}</td>
								<td>{{mem.mobile}}</td>
								<td>{{mem.email}}</td>
								<td>{{mem.address}}</td>
								<td>{{mem.designation}}</td>
								<td>{{mem.workexperience}}</td>
								<td>{{mem.joiningdate}}</td>
								<td>{{mem.salary}}</td>
							</tr>
						</tbody>
					</table>
					</div>
					
				</div>

			</div>	
		</div>
	</div>

	<!-- <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button> -->
	<!-- Modal -->
	<div class="modal fade" id="addmember" tabindex="-1" aria-labelledby="addmember1" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h1 class="modal-title fs-5" id="addmember1">Add Room</h1>
					 
				</div>
				<div class="modal-body" >

					<div class="col-12 row">

						<div class="col-4 my-2">
							<label>Name</label>

						</div>
						<div class="col-8 my-2">
							<input type="" name="" class="form-control form-control-sm" ng-model="name">

						</div>

						<div class="col-4 my-2">
							<label>Mobile No.</label>

						</div>
						<div class="col-8 my-2">
							<input type="number" name="" class="form-control form-control-sm" ng-model="mobileno">

						</div>
						<div class="col-4 my-2">
							<label>E-mail</label>

						</div>
						<div class="col-8 my-2">
							<input type="email" name="" class="form-control form-control-sm" ng-model="email">

						</div>
						<div class="col-4 my-2">
							<label>Address</label>

						</div>
						<div class="col-8 my-2">
						  <textarea type="" name="" class="form-control form-control-sm" ng-model="address"></textarea>

						</div>

						<div class="col-4 my-2">
							<label>Designation</label>

						</div>
						<div class="col-8 my-2">
							<input type="" name="" class="form-control form-control-sm" ng-model="designation">

						</div>
						<div class="col-4 my-2">
							<label>Work Experience</label>

						</div>
						<div class="col-8 my-2">
							<input type="" name="" class="form-control form-control-sm" ng-model="workexperience">

						</div>
						<div class="col-4 my-2">
							<label>Joining Date </label>

						</div>
						<div class="col-8 my-2">
							<input type="date" name="" class="form-control form-control-sm" ng-model="joiningdate">

						</div>
						<div class="col-4 my-2">
							<label>Salary</label>

						</div>
						<div class="col-8 my-2">
							<input type="" name="" class="form-control form-control-sm" ng-model="salary">

						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default btn-sm" data-bs-dismiss="modal"></button>
					<button type="button" class="btn btn-primary btn-sm" ng-click="add_member(name, mobileno, email, address, designation, workexperience, joiningdate, salary)">Add</button>
				</div>
			</div>
		</div>
	</div>

</div>

