<?php 
	session_start();
if($_SESSION['id']==''){
	header("location:".$baseurl.'login');
}
 ?>

<script src="<?php echo $baseurl; ?>jscontroller/restaurant.js"></script>
<div class="content-page" ng-controller="restaurantcontroller" ng-cloak>
	<div class="container-fluid">
		<div class="row content">
			<div class="col-sm-12 form-bg-color">
				<div class="container" >
					<h3>Food Item</h3>
					<!-- Button trigger modal -->
					<button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#fooditem" style="float: right;">
					  Add Food
					</button><br>
					<hr>
					<!-- Modal -->
					<div class="modal fade" id="fooditem" tabindex="-1" aria-labelledby="fooditem1" aria-hidden="true">
					  <div class="modal-dialog">
					    <div class="modal-content">
					      <div class="modal-header">
					        <h1 class="modal-title fs-5" id="fooditem1">Add Room</h1>
					       <!--  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button> -->
					      </div>
					      <div class="modal-body" >
					       
					       <div class="col-12 row">
					       	
					       	<div class="col-4 my-2">
					       		<label>Food Name</label>
					       		
					       	</div>
					       	<div class="col-8 my-2">
					       		<input type="" name="" class="form-control form-control-sm" ng-model="foodname">
					       		 
					       	</div>

					       	<div class="col-4 my-2">
					       		<label>Category</label>
					       		
					       	</div>
					       	<div class="col-8 my-2">
					       		<input type="" name="" class="form-control form-control-sm" ng-model="category">
					       		 
					       	</div>
					       	<div class="col-4 my-2">
					       		<label>Image</label>
					       		
					       	</div>
					       	<div class="col-8 my-2">
					       		<input type="file" id="file" name="file" class="form-control form-control-sm" ng-model="file" accept="image/*" ngf-select  ngf-max-size="100MB" ngf-model-invalid="errorFile">
					       		
					       	</div>
					       		<div class="col-4 my-2">
					       		<label>Price</label>
					       		
					       	</div>
					       	
					       	<div class="col-8 my-2">
					       		<input type="" name="" class="form-control form-control-sm" ng-model="price">
					       		 
					       	</div>
					       	
					       </div>
					      </div>
					      <div class="modal-footer">
					        <button type="button" class="btn btn-default btn-sm" data-bs-dismiss="modal"></button>
					        <button type="button" class="btn btn-primary btn-sm" ng-click="add_food(foodname,category, file,price)">Add</button>
					      </div>
					    </div>
					  </div>
					</div>
					<br>
					<table class="table table-bordered">
						<thead>
						<tr style="background-color: #efefef;">
							<th>Food Name</th>
							<th>Category</th>
							<th>Image</th>
							<th>Price</th>
							
						</tr>	
						</thead>
						<tbody>
						<tr ng-repeat="mes in allfoods | toArray">
							
							<td>{{mes.foodname}}</td>
							<td>{{mes.category}}</td>
							<td><img src="<?php echo $imageurl; ?>h_image/{{mes.image}}" style="height:50px; width: 75px;"></td>
							<td>{{mes.price}}</td>
							
							
						</tr>
						
						</tbody>
						
					</table>
					
				
				

				</div>
				
			</div>
		</div>
	</div>
</div>