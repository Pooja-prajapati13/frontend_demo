<?php 
	session_start();
if($_SESSION['id']==''){
	header("location:".$baseurl.'login');
}
 ?>

<script src="<?php echo $baseurl; ?>jscontroller/facilities.js"></script>
<div class="content-page" ng-controller="facilitiescontroller" ng-cloak>
	<div class="container-fluid">
		<div class="row content">
			<div class="col-sm-12 form-bg-color">
				

			
				<div class="container" >
					<h3>Add Facilities</h3><br>
					<!-- Button trigger modal -->
					
					<div class="col-12 row">
						<div class="col-4">
							<label>Facilities Name</label>
							
							<select  class="form-control form-control-sm"  style="width: 100%; margin-top: 5%;" ng-model="facilitiesname">
								<option></option>
								<option>Standard Room</option>
								<option>Superior Room</option>
								<option>Junior Suite</option>
								<option>Grand Superior Room</option>
								<option>Deluxe Room</option>
								<option>Family Special</option>
								<option>Premium Room</option>
							</select>
						</div>
						<div class="col-4">
							<label>Facility </label>
							<select class="form-control form-control-sm" style="width: 100%; margin-top: 5%;" ng-model="facility" id="facility">
								<option></option>
								<option>Parking</option>
								<option>View</option>
								<option>Restaurant</option>
								<option>Room service</option>
								<option>Smoking</option>
								<option>Free WiFi</option>
								<option>Family rooms</option>
								<option>Tea/coffee maker</option>
								<option>Breakfast</option>
								<option>Fun Things To Do</option>
								<option>Pets Allowed</option>
								<option>24-hour Front Desk</option>
								<option>Fitness Centre</option>
								<option>Spa & Wellness Centre</option>
								<option>Electric vehicle Charging Station</option>
								<option>Swimming Pool</option>
								<option>Room Facility</option>
								<option>Bathroom</option>
								<option>Room Size</option>
								<option>Information</option>
							</select>
							<!-- <select class="form-control form-control-sm" style="width: 100%; margin-top: 5%;">
								
							</select> -->
						</div>
						<div class="col-4">
							<label>Description</label>
							<textarea  type="" name="" class="form-control form-control-sm" style="width: 100%; margin-top: 5%;" ng-model="description"></textarea>
						</div>
						
					</div><br>
					<button type="button" class="btn btn-primary btn-sm"  style="float: right;" ng-click="save_facilities(facilitiesname,facility,description)">
					  Save
					</button><br>
					<hr>
					<!-- Modal -->
					
				
				
					<table class="table  table-bordered">
						<tr style="background-color: #efefef;" >
							<th>Facilities Name</th>
						
							<th>Facility</th>
							
							<th>Description</th>
							<th style="width: 8%;">Action</th>
						</tr>
						
						<tr ng-repeat="met in allfacilities | toArray">
							<td>{{met.facilitiesname}}</td>
							<td>{{met.facility}}</td>
							<td>{{met.description}}</td>
							<td>
							<button class="btn btn-primary btn-sm" ng-click="edit()"><i class="fa fa-pencil-square" aria-hidden="true"></i></button>
							<!-- <button class="btn btn-danger btn-sm" ng-click="delete(facilitiesname,facility,description)"><i class="fa fa-trash" aria-hidden="true"></i></button> -->
							<button type="button" class="btn btn-danger btn-sm" ng-click="delete_facilities_modal(met.slug)"><i class="fa fa-trash" aria-hidden="true"></i>
								</button>
						 </td>
						</tr>
						
					</table>
					<!-- delete modal -->
					<!-- Button trigger modal -->
					
					<div class="modal fade" id="deletefacilities" tabindex="-1" aria-labelledby="deletefacilitiesLabel" aria-hidden="true">
						  <div class="modal-dialog">
						    <div class="modal-content">
						      <div class="modal-header " style="padding: 1%;">
						        <h5 class="modal-title fs-5" id="deletefacilitiesLabel">Delete Confirmation</h5>
						        <button type="button" class="btn-close btn-sm" data-bs-dismiss="modal" aria-label="Close"></button>
						      </div>
						      <div class="modal-body">
						        Do you delete you want to delete this record ?
						      </div>
						      <div class="modal-footer" style="padding: 1%;">
						        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
						        <button type="button" class="btn btn-danger btn-sm" ng-click="delete_facilities(slugg)">Delete</button>
						      </div>
						    </div>
						  </div>
						</div>
				

				</div>
			
			
		
			</div>
			
		</div>
		
	</div>
	
</div>