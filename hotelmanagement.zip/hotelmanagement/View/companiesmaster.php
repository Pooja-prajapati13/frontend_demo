<?php 
	session_start();
if($_SESSION['id']==''){
	header("location:".$baseurl.'login');
}
 ?>

<script src="<?php echo $baseurl; ?>jscontroller/companiesmaster.js"></script>
<div class="content-page" ng-controller="companiesmastercontroller" ng-cloak>
	<div class="container-fluid">
		<div class="row content">

			<div class="col-sm-12 form-bg-color" style="">
				<h3 style="padding: 1%; margin-top: 1%;">Company Form</h3>
				
                <div class="container"  style="padding: 2%; margin-top: 2%;">
					<fieldset class="border p-2">
                    <legend class="float-none w-auto p-1"></legend>
						<div class="col-12 row p-2">
							<div class="customer col-4">
								<label>Company Name</label><br>
								<input class="form-control form-control-sm"   style="margin-top: 1%;" ng-model="companyname">
	        					 <br>
								
								<label>Email</label><br>
								<input type="email"class="form-control form-control-sm" style="margin-top: 1%;" ng-model="email">
								 <br>	
							</div>	
							<div class="customer col-4">
								<label>Phone no.</label><br>
								<input class="form-control form-control-sm"   style="margin-top: 1%;" ng-model="phone">
	        					<br>
								<label>Address</label><br>
								<textarea class="form-control form-control-sm"   style="margin-top: 1%;" ng-model="address"></textarea>
	        					<br>
								<button class="btn btn-success btn-sm" ng-click="save_companies(companyname, phone, mobile, email, address, gst)" style="float: right;">Save</button>
							</div>
							<div class="customer col-4">
								<label>Mobile No. </label><br>
								<input type="" id="" name=""class="form-control form-control-sm" style="margin-top: 1%;" ng-model="mobile"> <br>
								<label>GST No.</label><br>
								<input type="" id="" name=""class="form-control form-control-sm" style="margin-top: 1%;" ng-model="gst"> <br>
								
								
							</div>


						</div>
                    </fieldset>
				</div>
				<div class="container"  style="padding: 2%; margin-top: 2%;">
					
						<div class="table-responsive">
						<table class="table table-bordered" >
						<thead>
							<tr style="background-color: #efefef;">
								<th>SN</th>
								<th>Company Name</th>
								<th>Phone</th>
								<th>Mobile</th>
								<th>Email</th>
								<th>Address</th>
								<th>Gst</th>
								<th>Action</th>
							</tr>
						</thead>
						<tbody>
							<tr ng-repeat="companies in allcompanies | toArray">
								<td>#</td>
								<td>{{companies.companyname}}</td>
								<td>{{companies.phone}}</td>
								<td>{{companies.mobile}}</td>
								<td>{{companies.email}}</td>
								<td>{{companies.address}}</td>
								<td>{{companies.gst}}</td>
								<td><button type="button" class="btn btn-primary btn-sm" ng-click="update_companies_modal(companies.id)" ><i class="fa fa-pencil-square" aria-hidden="true"></i></button>
								<button type="button" class="btn btn-danger btn-sm" ng-click="delete_companies_modal(companies.id)"><i class="fa fa-trash" aria-hidden="true"></i>
								</button></td>
								
							</tr>
						</tbody>
					</table>
					</div>		
					
				</div>
				
				<!-- Modal -->
				<div class="modal fade" id="updatecompanies" tabindex="-1" aria-labelledby="updatecompanieslabel" aria-hidden="true">
				  <div class="modal-dialog modal-xl">
				    <div class="modal-content">
				      <div class="modal-header">
				        <h5 class="modal-title fs-5" id="updatecompanieslabel">Edit</h5>
				        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				      </div>
				      <div class="modal-body">
				        <div class="col-12 row p-2">
							<div class="customer col-4">
								<label>Company Name </label><br>
								<input type="" id="" name="" class="form-control form-control-sm" style="margin-top: 1%;" ng-model="update_companyname" ><br>	
							</div>	
							<div class="customer col-4">
								
								<label>Phone</label><br>
								<input type="" id="" name="" class="form-control form-control-sm" style="margin-top: 1%;" ng-model="update_phone" ><br>
								
							</div>
							<div class="customer col-4">
								
								<label>Mobile</label><br>
								<input type="" id="" name="" class="form-control form-control-sm" style="margin-top: 1%;" ng-model="update_mobile" ><br>
								
							</div>
							<div class="customer col-4">
								
								<label>Email</label><br>
								<input type="" id="" name="" class="form-control form-control-sm" style="margin-top: 1%;" ng-model="update_email" ><br>
								
							</div>
							<div class="customer col-4">
								
								<label>Address</label><br>
								<input type="" id="" name="" class="form-control form-control-sm" style="margin-top: 1%;" ng-model="update_address" ><br>
								
							</div>
							<div class="customer col-4">
								
								<label>Gst</label><br>
								<input type="" id="" name="" class="form-control form-control-sm" style="margin-top: 1%;" ng-model="update_gst" ><br>
								
							</div>
							


						</div>
				      </div>
				      <div class="modal-footer">
				        <button type="button" class="btn btn-light mr-1" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary btn-sm" id="btn-update-event" ng-click="update_companies(id,update_companyname, update_phone, update_mobile, update_email, update_address, update_gst)">Update</button>
				      </div>
				    </div>
				  </div>
				</div>

				<!-- delete modal -->
				<div class="modal fade" id="deletecompanies" tabindex="-1" aria-labelledby="deletecompanieslabel" aria-hidden="true">
						  <div class="modal-dialog">
						    <div class="modal-content">
						      <div class="modal-header " style="padding: 1%;">
						        <h5 class="modal-title fs-5" id="deletecompanieslabel">Delete Confirmation</h5>
						        <button type="button" class="btn-close btn-sm" data-bs-dismiss="modal" aria-label="Close"></button>
						      </div>
						      <div class="modal-body">
						        Do you delete you want to delete this record ?
						      </div>
						      <div class="modal-footer" style="padding: 1%;">
						        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
						        <button type="button" class="btn btn-danger btn-sm" ng-click="delete_companies(id)">Delete</button>
						      </div>
						    </div>
						  </div>
					</div>
				
			</div>
				

		</div>
	</div>
</div>


<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<!-- <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
 -->
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script> -->
<script type="text/javascript">
	$(function () {
  $('select').each(function () {
    $(this).select2({
      theme: 'bootstrap4',
      width: 'style',
      placeholder: $(this).attr('placeholder'),
      allowClear: Boolean($(this).data('allow-clear')),
    });
  });
});
</script>

<!-- <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script> -->
<!-- </html> -->