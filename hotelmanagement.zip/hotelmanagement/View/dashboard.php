 <?php
session_start();
if($_SESSION['id']==''){
	header("location:".$baseurl.'login');
}

    $urldesc = "hotelmanagement";

    // 
// $start = ($page - 1) * $dataperpage;

   

// 
    $data=$roomdashboard->fetch_all_room();
// echo '<pre>';print_r($data);die();
?>

<?php
$id=$_GET['id'];
?>
 <script src="<?php echo $baseurl; ?>jscontroller/dashboard.js"></script>
<div  ng-controller="dashboardcontroller" ng-cloak>


<div class="content-page">
	<div class="container-fluid">
		<div class="row content">
			<div class="col-sm-12 form-bg-color">
				
				<div class="container" >
					<div class="col-12 row">
						<div class="col-4">
							<h3>	Hotel Master</h3>
						</div>
						<div class="col-8">
							<div class="col-12 row">
								<div class="col-4">
									<div class="card">
									  <div class="row">
									    <div class="col-4" style="background-color: #fbc705;">
									      
									      <i class="fa fa-users" aria-hidden="true" style="font-size:48px;color:white; padding-top: 10px;"></i>
									    </div>
									    <div class="col-md-8">
									        <p class="card-text">2</p>
									        <p class="card-text"><small class="text-body-secondary">Total Booked Room</small></p>
									      
									    </div>
									  </div>
									</div>

								</div>
								<div class="col-4">
									<div class="card">
									  <div class="row">
									    <div class="col-4" style="background-color: #fb1b05;">
									      
									      <i class="fa fa-filter" aria-hidden="true" style="font-size:48px;color:white; padding-top: 10px;"></i>
									    </div>
									    <div class="col-md-8">
									        <p class="card-text">2</p>
									        <p class="card-text"><small class="text-body-secondary">Today Checkout</small></p>
									      
									    </div>
									  </div>
									</div>
									
								</div>
								<div class="col-4">
									<div class="card">
									  <div class="row">
									    <div class="col-4" style="background-color: #05befb;">
									      
									      <i class="fa fa-leaf" aria-hidden="true" style="font-size:48px;color:white; padding-top: 10px;"></i>
									    </div>
									    <div class="col-md-8">
									        <p class="card-text"><?php echo sizeof($data); ?></p>
									        <p class="card-text"><small class="text-body-secondary">Total Rooms</small></p>
									      
									    </div>
									  </div>
									</div>
									
								</div>
							</div>
							
						</div>
						
					
					</div>
					
					<div class="container-fluid"><br>
						
						
						
						<hr><br>
						<div class="col-12" style="background-color: #efefef;">
							<i class="fa fa-bar-chart p-2" aria-hidden="true" style="font-size: 30px;">&emsp;<small>Hotel Room Booking</small></i>
							
						<div class="row">
						<?php  
							foreach ($data as  $room) {
								
							$roomdata=$roomdashboard->check_room($room['roomno']);
							if($roomdata!=''){

						?>
						

						 <div class="col-sm-2 pt-5" >
						    <div class="card" style="background-color:#9a0d0d; ">
						      	<i class="fa fa-home p-3" aria-hidden="true" style="font-size:48px;color:white;">&nbsp;<small class="fs-5"><?php echo $room['roomno']; ?></small></i>
						      	<a href="<?php echo $baseurl;?>Room_order/<?php echo $roomdata[0]['slug'] ?>" style="color:#fff;">Add Order</a>
						      	<a href="<?php echo $baseurl;?>Room_checkout/<?php echo $roomdata[0]['slug'] ?>" style="color:#fff;">Checkout</a>
						      <a href="<?php echo $baseurl;?>Registeration" class="btn btn-dark btn-sm" style="float: right; width: 30%;">AC</a>
						    </div>
						  </div> 
						<?php } else{  ?>
						  <div class="col-sm-2 pt-5" >
						    <div class="card" style="background-color:#05befb; ">
						      	<i class="fa fa-home p-3" aria-hidden="true" style="font-size:48px;color:white;">&nbsp;<small class="fs-5"><?php echo $room['roomno']; ?></small></i>
						      <a href="<?php echo $baseurl;?>Registeration" class="btn btn-dark btn-sm" style="float: right; width: 30%;">AC</a>
						    </div>
						  </div> 

						  <?php  
						  	}

						  	}
						  ?>

						  
						 
						  
						</div>
						</div>
						
						<!-- <table class="table ">
						<tr style="background-color: #efefef;">
							<th><i class="fa fa-bar-chart" aria-hidden="true"></i>&emsp; Hotel Booking Room</th>

						</tr>
							
						
					</table> -->
					</div>
				

				</div>
			</div>
		</div>
	</div>
</div>