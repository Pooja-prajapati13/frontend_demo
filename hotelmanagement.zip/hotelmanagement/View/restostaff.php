<script src="<?php echo $baseurl; ?>jscontroller/restostaff.js"></script>
<div class="content-page" ng-controller="restostaffcontroller" ng-cloak>
	<div class="container-fluid">
		<div class="row content">
			<div  class="col-sm-12 form-bg-color">
				<div class="container" >
					<h3>Restaurant Staff</h3>
					<!-- Button trigger modal -->
					<button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#restomember" style="float: right;">
					  Add Members
					</button><br>
					<hr>
					<!-- Modal -->
					<div class="modal fade" id="restomember" tabindex="-1" aria-labelledby="restomember1" aria-hidden="true">
					  <div class="modal-dialog">
					    <div class="modal-content">
					      <div class="modal-header">
					        <h1 class="modal-title fs-5" id="restomember1">Add Room</h1>
					       <!--  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button> -->
					      </div>
					      <div class="modal-body" >
					       
					       <div class="col-12 row">
					       	
					       	<div class="col-4 my-2">
					       		<label>Name</label>
					       		
					       	</div>
					       	<div class="col-8 my-2">
					       		<input type="" name="" class="form-control form-control-sm" ng-model="name">
					       		 
					       	</div>

					       		<div class="col-4 my-2">
					       		<label>Mobile No.</label>
					       		
					       	</div>
					       	<div class="col-8 my-2">
					       		<input type="number" name="" class="form-control form-control-sm" ng-model="mobileNo">
					       		 
					       	</div>
					       		<div class="col-4 my-2">
					       		<label>E-mail</label>
					       		
					       	</div>
					       	<div class="col-8 my-2">
					       		<input type="email" name="" class="form-control form-control-sm" ng-model="email">
					       		 
					       	</div>
					       		<div class="col-4 my-2">
					       		<label>Address</label>
					       		
					       	</div>
					       	<div class="col-8 my-2">
					       		<textarea type="" name="" class="form-control form-control-sm" ng-model="address"></textarea>
					       		 
					       	</div>

					       	<div class="col-4 my-2">
					       		<label>Designation</label>
					       		
					       	</div>
					       	<div class="col-8 my-2">
					       		<input type="" name="" class="form-control form-control-sm" ng-model="designation">
					       		 
					       	</div>
					       		<div class="col-4 my-2">
					       		<label>Work Experience</label>
					       		
					       	</div>
					       	<div class="col-8 my-2">
					       		<input type="" name="" class="form-control form-control-sm" ng-model="workexperience">
					       		 
					       	</div>
					       		<div class="col-4 my-2">
					       		<label>Joining Date </label>
					       		
					       	</div>
					       	<div class="col-8 my-2">
					       		<input type="date" name="" class="form-control form-control-sm" ng-model="joiningdate">
					       		 
					       	</div>
					       	<div class="col-4 my-2">
					       		<label>Salary</label>
					       		
					       	</div>
					       	<div class="col-8 my-2">
					       		<input type="" name="" class="form-control form-control-sm" ng-model="salary">
					       		 
					       	</div>
					       </div>
					      </div>
					      <div class="modal-footer">
					        <button type="button" class="btn btn-default btn-sm" data-bs-dismiss="modal"></button>
					        <button type="button" class="btn btn-primary btn-sm" ng-click="add_members(name, mobileno, email, address, designation, workexperience, joiningdate, salary)">Adding</button>
					      </div>
					    </div>
					  </div>
					</div>
					<br>
					<table class="table table-bordered">
						<thead>
						<tr style="background-color: #efefef;">
							<th>Name</th>
							
							<th>MobileNo.</th>
							<th>E-mail</th>
							<th>Address</th>
							<th>Designation</th>
							<th>Work Experience</th>
							<th>Joining Date</th>
							<th>Salary (in Rs.)</th>
						</tr>
						</thead>
						<tbody>
							<tr ng-repeat="men in allstaff | toArray">
								<td>{{men.name}}</td>
								<td>{{men.mobile}}</td>
								<td>{{men.email}}</td>
								<td>{{men.address}}</td>
								<td>{{men.designation}}</td>
								<td>{{men.workexperience}}</td>
								<td>{{men.joiningdate}}</td>
								<td>{{men.salary}}</td>
							</tr>
						</tbody>
						
						
						
					
					</table>
					
				
				

				</div>
			</div>
		</div>
	</div>
</div>