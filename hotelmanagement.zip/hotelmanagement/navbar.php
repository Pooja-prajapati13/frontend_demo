<nav class="navbar navbar-expand-lg bg-body-primary" style="background-color: #000;">
  <div class="container-fluid">
    <!-- <a class="navbar-brand" href="#">Navbar</a> -->
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <!-- <a class="nav-link active" aria-current="page" href="#">Home</a> -->
        </li>
        <li class="nav-item">
          <!-- <a class="nav-link" href="#">Link</a> -->
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Master
          </a>
          <ul class="dropdown-menu">
            <!-- <li><a class="dropdown-item" href="<?php echo $baseurl;?>Session_master">Session Master</a></li> -->
            <li><a class="dropdown-item" href="<?php echo $baseurl;?>Companies_master">Companies Master</a></li> 
            <li><a class="dropdown-item" href="<?php echo $baseurl;?>Designation_master">Designation Master</a></li>
            <li><a class="dropdown-item" href="<?php echo $baseurl;?>Unit_master">Unit Master</a></li>
            <li><a class="dropdown-item" href="<?php echo $baseurl;?>Occupy_master">Occupy Master</a></li>
            <li><a class="dropdown-item" href="<?php echo $baseurl;?>Room_category_master">Room Category Master</a></li>
            <li><a class="dropdown-item" href="<?php echo $baseurl;?>Menu_category_master">Menu Category Master</a></li>
            <li><a class="dropdown-item" href="<?php echo $baseurl;?>Menu_item_master">Menu Item Master</a></li>
            <li><a class="dropdown-item" href="<?php echo $baseurl;?>Table_master">Table Master</a></li>
            <li><a class="dropdown-item" href="<?php echo $baseurl;?>Room_master">Room Master</a></li>
            <li><a class="dropdown-item" href="<?php echo $baseurl;?>Customer_master">Customer Master</a></li>
            <li><a class="dropdown-item" href="<?php echo $baseurl;?>Employee_master">Employee Master</a></li>
            <!-- <li><hr class="dropdown-divider"></li> -->
            <!-- <li><a class="dropdown-item" href="#">Something else here</a></li> -->
          </ul>
        </li>
        <li class="nav-item">
          <!-- <a class="nav-link disabled">Disabled</a> -->
        </li>
      </ul>
      <!-- <form class="d-flex" role="search">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Search</button>
      </form> -->
    </div>
  </div>
</nav>