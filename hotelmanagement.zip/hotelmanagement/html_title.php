<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>hotelmanagement</title>
	<meta content="A fully featured admin for maintenance of games" name="description" />
<meta content="Games" name="author" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />