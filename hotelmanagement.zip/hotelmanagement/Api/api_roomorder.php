<?php
include_once '../td_includes.php';

	$_POST = json_decode(file_get_contents('php://input'), true);

	// if($_POST['action']=="login_user"){

	// 	$userid = $_POST['userid'];
	// 	$password = $_POST['password'];

	// 	$data=$login->login_user($userid,md5($password));
	// 	if ($data) {
	// 		if($data=="Invalid Userid or Password"){
	// 			$message = "Invalid Userid or Password.";
	// 		}
	// 		else {
	// 			$_SESSION['userslug'] = $data;
	// 			$message = "Success";
	// 		}
	// 	}
	// 	else{
	// 		$message = "Something went wrong. Please try after some time.";
	// 	}

	// 	$message= (object) $message;
 //        $json = json_encode($message);
 //        echo $json; 
	// }
  

	if($_POST['action']=="add_order"){

		$service = $_POST['service'];
		$rate = $_POST['rate'];
		$quantity = $_POST['quantity'];
		$total = $_POST['total'];
		$is_free = $_POST['is_free'];
		$slug = $_POST['slug'];
		$data=$roomorder->add_order($service,$rate,$quantity,$total,$is_free,$slug);
		if ($data) {
			$message = "Success";
		}
		else{
			$message = "Something went wrong. Please try after some time.";
		}

		$message= (object) $message;
        $json = json_encode($message);
        echo $json; 
	}

	if($_GET['action']=="fetch_all_order"){
		$data = $roomorder->fetch_all_order($_GET['registeration_no']);
		if($data){
			$data= (object) $data;
	        $json = json_encode($data);
	        echo $json;
		}
		else{
			echo "Invalid request";
		}
	}

	// if($_GET['action']=="fetch_customer_detail"){
	// 	$data = $customer->fetch_customer_detail($_GET['slug']);
	// 	if($data){
	// 		$data= (object) $data;
	//         $json = json_encode($data);
	//         echo $json;
	// 	}
	// 	else{
	// 		echo "Invalid request";
	// 	}
	// }

	// if($_GET['action']=="detail_customer_modal"){

	// 	$data = $customer->detailcustomer($_GET['slug']);
	// 	if($data){
	// 		$message="success";
	// 		$message= (object) $message;
	//         $json = json_encode($message);
	//         echo $json;
	// 	}
		
	// }
	

	// if($_GET['action']=="delete_customer"){

	// 	$data = $customer->delete_customer($_GET['slug']);
	// 	if($data){
	// 		$message="success";
	// 		$message= (object) $message;
	//         $json = json_encode($message);
	//         echo $json;
	// 	}
		
	// }
?>