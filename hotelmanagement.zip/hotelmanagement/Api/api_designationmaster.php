<?php
include_once '../td_includes.php';

	$_POST = json_decode(file_get_contents('php://input'), true);

	// if($_POST['action']=="login_user"){

	// 	$userid = $_POST['userid'];
	// 	$password = $_POST['password'];

	// 	$data=$login->login_user($userid,md5($password));
	// 	if ($data) {
	// 		if($data=="Invalid Userid or Password"){
	// 			$message = "Invalid Userid or Password.";
	// 		}
	// 		else {
	// 			$_SESSION['userslug'] = $data;
	// 			$message = "Success";
	// 		}
	// 	}
	// 	else{
	// 		$message = "Something went wrong. Please try after some time.";
	// 	}

	// 	$message= (object) $message;
 //        $json = json_encode($message);
 //        echo $json; 
	// }
  

	if($_POST['action']=="save_designation"){
		$id=$_POST['id'];
		$designation_name = $_POST['designation_name'];
		$designation_status = $_POST['designation_status'];
		$data=$designationmaster->save_designation($designation_name,$designation_status);
		if ($data) {
			$message = "Success";
		}
		else{
			$message = "Something went wrong. Please try after some time.";
		}

		$message= (object) $message;
        $json = json_encode($message);
        echo $json; 
	}

	if($_GET['action']=="fetch_all_designation"){
		$data = $designationmaster->fetch_all_designation();
		if($data){
			$data= (object) $data;
	        $json = json_encode($data);
	        echo $json;
		}
		else{
			echo "Invalid request";
		}
	}

	if($_GET['action']=="fetch_designation_detail"){
		$data = $designationmaster->fetch_designation_detail($_GET['id']);
		if($data){
			$data= (object) $data;
	        $json = json_encode($data);
	        echo $json;
		}
		else{
			echo "Invalid request";
		}
	}

	if($_POST['action']=="update_designation"){
		
		$designation_name = $_POST['update_designation_name'];
		$designation_status = $_POST['update_designation_status'];

		$data = $designationmaster->update_designation($_POST['id'],$designation_name,$designation_status);
		if($data){
			$message="success";
			$message= (object) $message;
	        $json = json_encode($message);
	        echo $json;
		}
		
	}

	if($_GET['action']=="delete_designation"){
		$data = $designationmaster->delete_designation($_GET['id']);
		if($data){
			$message="success";
			$message= (object) $message;
	        $json = json_encode($message);
	        echo $json;
		}
		
	}


	// if($_GET['action']=="fetch_customer_detail"){
	// 	$data = $customer->fetch_customer_detail($_GET['slug']);
	// 	if($data){
	// 		$data= (object) $data;
	//         $json = json_encode($data);
	//         echo $json;
	// 	}
	// 	else{
	// 		echo "Invalid request";
	// 	}
	// }

	// if($_GET['action']=="detail_customer_modal"){

	// 	$data = $customer->detailcustomer($_GET['slug']);
	// 	if($data){
	// 		$message="success";
	// 		$message= (object) $message;
	//         $json = json_encode($message);
	//         echo $json;
	// 	}
		
	// }
	

	// if($_GET['action']=="delete_customer"){

	// 	$data = $customer->delete_customer($_GET['slug']);
	// 	if($data){
	// 		$message="success";
	// 		$message= (object) $message;
	//         $json = json_encode($message);
	//         echo $json;
	// 	}
		
	// }
?>