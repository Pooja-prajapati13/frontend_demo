<?php
include_once '../td_includes.php';

	$_POST = json_decode(file_get_contents('php://input'), true);

	// if($_POST['action']=="login_user"){

	// 	$userid = $_POST['userid'];
	// 	$password = $_POST['password'];

	// 	$data=$login->login_user($userid,md5($password));
	// 	if ($data) {
	// 		if($data=="Invalid Userid or Password"){
	// 			$message = "Invalid Userid or Password.";
	// 		}
	// 		else {
	// 			$_SESSION['userslug'] = $data;
	// 			$message = "Success";
	// 		}
	// 	}
	// 	else{
	// 		$message = "Something went wrong. Please try after some time.";
	// 	}

	// 	$message= (object) $message;
 //        $json = json_encode($message);
 //        echo $json; 
	// }
  

	if($_POST['action']=="save_employee_master"){
		$id=$_POST['id'];
		$employee_name = $_POST['employee_name'];
		$designation_name = $_POST['designation_name'];
		$employee_status = $_POST['employee_status'];
		$data=$employeemaster->save_employee_master($employee_name,$designation_name,$employee_status);
		if ($data) {
			$message = "Success";
		}
		else{
			$message = "Something went wrong. Please try after some time.";
		}

		$message= (object) $message;
        $json = json_encode($message);
        echo $json; 
	}
	if($_GET['action']=="fetch_all_employee"){
		$data = $employeemaster->fetch_all_employee();
		if($data){
			$data= (object) $data;
	        $json = json_encode($data);
	        echo $json;
		}
		else{
			echo "Invalid request";
		}
	}

	if($_GET['action']=="fetch_employee_detail"){
		$data = $employeemaster->fetch_employee_detail($_GET['id']);
		if($data){
			$data= (object) $data;
	        $json = json_encode($data);
	        echo $json;
		}
		else{
			echo "Invalid request";
		}
	}

	if($_POST['action']=="update_employee"){
		
		$employee_name = $_POST['update_employee_name'];
		$designation_name = $_POST['update_designation_name'];
		$employee_status = $_POST['update_employee_status'];

		$data = $employeemaster->update_employee($_POST['id'],$employee_name,$designation_name,$employee_status);
		if($data){
			$message="success";
			$message= (object) $message;
	        $json = json_encode($message);
	        echo $json;
		}
		
	}

	if($_GET['action']=="delete_employee"){
		$data = $employeemaster->delete_employee($_GET['id']);
		if($data){
			$message="success";
			$message= (object) $message;
	        $json = json_encode($message);
	        echo $json;
		}
		
	}
	// if($_GET['action']=="fetch_all_customer"){
	// 	$data = $customer->fetch_all_customer();
	// 	if($data){
	// 		$data= (object) $data;
	//         $json = json_encode($data);
	//         echo $json;
	// 	}
	// 	else{
	// 		echo "Invalid request";
	// 	}
	// }

	// if($_GET['action']=="fetch_customer_detail"){
	// 	$data = $customer->fetch_customer_detail($_GET['slug']);
	// 	if($data){
	// 		$data= (object) $data;
	//         $json = json_encode($data);
	//         echo $json;
	// 	}
	// 	else{
	// 		echo "Invalid request";
	// 	}
	// }

	// if($_GET['action']=="detail_customer_modal"){

	// 	$data = $customer->detailcustomer($_GET['slug']);
	// 	if($data){
	// 		$message="success";
	// 		$message= (object) $message;
	//         $json = json_encode($message);
	//         echo $json;
	// 	}
		
	// }
	

	// if($_GET['action']=="delete_customer"){

	// 	$data = $customer->delete_customer($_GET['slug']);
	// 	if($data){
	// 		$message="success";
	// 		$message= (object) $message;
	//         $json = json_encode($message);
	//         echo $json;
	// 	}
		
	// }
?>