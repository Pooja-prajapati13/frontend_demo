<?php
include_once '../td_includes.php';

	$_POST = json_decode(file_get_contents('php://input'), true);

	// if($_POST['action']=="login_user"){

	// 	$userid = $_POST['userid'];
	// 	$password = $_POST['password'];

	// 	$data=$login->login_user($userid,md5($password));
	// 	if ($data) {
	// 		if($data=="Invalid Userid or Password"){
	// 			$message = "Invalid Userid or Password.";
	// 		}
	// 		else {
	// 			$_SESSION['userslug'] = $data;
	// 			$message = "Success";
	// 		}
	// 	}
	// 	else{
	// 		$message = "Something went wrong. Please try after some time.";
	// 	}

	// 	$message= (object) $message;
 //        $json = json_encode($message);
 //        echo $json; 
	// }
  

	if($_POST['action']=="save_table_master"){
		$table_category = $_POST['table_category'];
		$table_code = $_POST['table_code'];
		$table_name = $_POST['table_name'];
		$table_status = $_POST['table_status'];
		$data=$tablemaster->save_table_master($table_category,$table_code,$table_name,$table_status);
		if ($data) {
			$message = "Success";
		}
		else{
			$message = "Something went wrong. Please try after some time.";
		}

		$message= (object) $message;
        $json = json_encode($message);
        echo $json; 
	}

	// if($_GET['action']=="fetch_all_customer"){
	// 	$data = $customer->fetch_all_customer();
	// 	if($data){
	// 		$data= (object) $data;
	//         $json = json_encode($data);
	//         echo $json;
	// 	}
	// 	else{
	// 		echo "Invalid request";
	// 	}
	// }

	// if($_GET['action']=="fetch_customer_detail"){
	// 	$data = $customer->fetch_customer_detail($_GET['slug']);
	// 	if($data){
	// 		$data= (object) $data;
	//         $json = json_encode($data);
	//         echo $json;
	// 	}
	// 	else{
	// 		echo "Invalid request";
	// 	}
	// }

	// if($_GET['action']=="detail_customer_modal"){

	// 	$data = $customer->detailcustomer($_GET['slug']);
	// 	if($data){
	// 		$message="success";
	// 		$message= (object) $message;
	//         $json = json_encode($message);
	//         echo $json;
	// 	}
		
	// }
	

	// if($_GET['action']=="delete_customer"){

	// 	$data = $customer->delete_customer($_GET['slug']);
	// 	if($data){
	// 		$message="success";
	// 		$message= (object) $message;
	//         $json = json_encode($message);
	//         echo $json;
	// 	}
		
	// }
?>