<?php
include_once '../td_includes.php';

	$_POST = json_decode(file_get_contents('php://input'), true);

	// if($_POST['action']=="login_user"){

	// 	$userid = $_POST['userid'];
	// 	$password = $_POST['password'];

	// 	$data=$login->login_user($userid,md5($password));
	// 	if ($data) {
	// 		if($data=="Invalid Userid or Password"){
	// 			$message = "Invalid Userid or Password.";
	// 		}
	// 		else {
	// 			$_SESSION['userslug'] = $data;
	// 			$message = "Success";
	// 		}
	// 	}
	// 	else{
	// 		$message = "Something went wrong. Please try after some time.";
	// 	}

	// 	$message= (object) $message;
 //        $json = json_encode($message);
 //        echo $json; 
	// }
  

	if($_POST['action']=="check_in"){
		$slug=md5(time());
		$registeration_no = $_POST['registeration_no'];
		$arrival_date = $_POST['arrival_date'];
		$arrival_time = $_POST['arrival_time'];
		$occupy = $_POST['occupy'];
		$guest_name = $_POST['guest_name'];
		$company_name = $_POST['company_name'];
		$company_gst = $_POST['company_gst'];
		$no_of_person = $_POST['no_of_person'];
		$mobiles = $_POST['mobiles'];
		$room_rent = $_POST['room_rent'];
		$advance = $_POST['advance'];
		$reference = $_POST['reference'];
		$room_no = $_POST['room_no'];
		$file = $_POST['file'];
		$guest_id = $_POST['guest_id'];
		$permanent_address = $_POST['permanent_address'];
		$nationality = $_POST['nationality'];
		$data=$registeration->check_in($slug,$registeration_no,$arrival_date,$arrival_time,$occupy,$guest_name,$company_name,$company_gst,$no_of_person,$mobiles,$room_rent,$advance,$reference,$room_no,$file,$guest_id,$permanent_address,$nationality);
		if ($data) {
			$message = "Success";
		}
		else{
			$message = "Something went wrong. Please try after some time.";
		}

		$message= (object) $message;
        $json = json_encode($message);
        echo $json; 
	}

	// if($_GET['action']=="fetch_all_customer"){
	// 	$data = $customer->fetch_all_customer();
	// 	if($data){
	// 		$data= (object) $data;
	//         $json = json_encode($data);
	//         echo $json;
	// 	}
	// 	else{
	// 		echo "Invalid request";
	// 	}
	// }

	// if($_GET['action']=="fetch_customer_detail"){
	// 	$data = $customer->fetch_customer_detail($_GET['slug']);
	// 	if($data){
	// 		$data= (object) $data;
	//         $json = json_encode($data);
	//         echo $json;
	// 	}
	// 	else{
	// 		echo "Invalid request";
	// 	}
	// }

	// if($_GET['action']=="detail_customer_modal"){

	// 	$data = $customer->detailcustomer($_GET['slug']);
	// 	if($data){
	// 		$message="success";
	// 		$message= (object) $message;
	//         $json = json_encode($message);
	//         echo $json;
	// 	}
		
	// }
	

	// if($_GET['action']=="delete_customer"){

	// 	$data = $customer->delete_customer($_GET['slug']);
	// 	if($data){
	// 		$message="success";
	// 		$message= (object) $message;
	//         $json = json_encode($message);
	//         echo $json;
	// 	}
		
	// }
?>