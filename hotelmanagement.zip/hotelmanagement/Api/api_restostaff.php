<?php
include_once '../td_includes.php';

	$_POST = json_decode(file_get_contents('php://input'), true);

	// if($_POST['action']=="login_user"){

	// 	$userid = $_POST['userid'];
	// 	$password = $_POST['password'];

	// 	$data=$login->login_user($userid,md5($password));
	// 	if ($data) {
	// 		if($data=="Invalid Userid or Password"){
	// 			$message = "Invalid Userid or Password.";
	// 		}
	// 		else {
	// 			$_SESSION['userslug'] = $data;
	// 			$message = "Success";
	// 		}
	// 	}
	// 	else{
	// 		$message = "Something went wrong. Please try after some time.";
	// 	}

	// 	$message= (object) $message;
 //        $json = json_encode($message);
 //        echo $json; 
	// }


	if($_POST['action']=="add_members"){

		$name = $_POST['name'];
		$mobileno = $_POST['mobileno'];
		$email = $_POST['email'];
		$address = $_POST['address'];
		$designation = $_POST['designation'];
		$workexperience = $_POST['workexperience'];
		$joiningdate = $_POST['joiningdate'];
		$salary = $_POST['salary'];
		

		$data=$restaurant_staff->add_members($name,$mobileno,$email,$address,$designation,$workexperience,$joiningdate,$salary);
		if ($data) {
			$message = "Success";
		}
		else{
			$message = "Something went wrong. Please try after some time.";
		}

		$message= (object) $message;
        $json = json_encode($message);
        echo $json; 
	}

	if($_GET['action']=="fetch_all_member"){
		$data = $restaurant_staff->fetch_all_resto_member();
		if($data){
			$data= (object) $data;
	        $json = json_encode($data);
	        echo $json;
		}
		else{
			echo "Invalid request";
		}
	}

?>