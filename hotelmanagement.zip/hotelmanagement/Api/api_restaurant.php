<?php
include_once '../td_includes.php';

	$_POST = json_decode(file_get_contents('php://input'), true);

	// if($_POST['action']=="login_user"){

	// 	$userid = $_POST['userid'];
	// 	$password = $_POST['password'];

	// 	$data=$login->login_user($userid,md5($password));
	// 	if ($data) {
	// 		if($data=="Invalid Userid or Password"){
	// 			$message = "Invalid Userid or Password.";
	// 		}
	// 		else {
	// 			$_SESSION['userslug'] = $data;
	// 			$message = "Success";
	// 		}
	// 	}
	// 	else{
	// 		$message = "Something went wrong. Please try after some time.";
	// 	}

	// 	$message= (object) $message;
 //        $json = json_encode($message);
 //        echo $json; 
	// }
	if ($_POST['action']=="add_food") {
			$slug=md5(time());
			$foodname=$_POST['foodname'];
			$category=$_POST['category'];
			$file=$_POST['file'];
			$price=$_POST['price'];            
			$valid_formats = array("jpg", "png", "jpeg","gif");

			$name=$_FILES['file']['name'];
			$filename = stripslashes($name);
			$tempfile=$_FILES["file"]["tmp_name"];
			$filesize=$_FILES['file']['size'];
			$ext = $tdcont->getExtension($filename);
			$ext = strtolower($ext);
			
	         if(in_array($ext,$valid_formats)){
				if($filesize<(1024*51200) ){
					$actual_m_sliderImg_name = 'h_image'.$slug.'.'.$ext;
					$target_file =$Iconuploadpath.'image/'.basename($actual_h_image);         
					$imgpath= $imageurl.basename($actual_h_image);
					$imgname=basename($actual_h_image);

					if (move_uploaded_file($tempfile,$target_file))
					{
						$save=$data->add_food($foodname,$category,$imgname,$price,$slug);
						if ($save) {
							echo "Media successfully uploaded.";
						}
						else{
							echo "Somehthing went wrong, please try again.";
						}
					}
				}
				else{
					echo "File size exceed to 50MB";
				}
			}
			else{
				echo "May be you have selected an invalid file or not selected any files.";
			}
		
}

	// if($_POST['action']=="add_food"){

	// 	$foodname = $_POST['foodname'];
	// 	$category = $_POST['category'];
	// 	$image = $_POST['image'];
	// 	$price = $_POST['price'];
		
		

	// 	$data=$restaurant->add_food($foodname,$category,$image,$price);
	// 	if ($data) {
	// 		$message = "Success";
	// 	}
	// 	else{
	// 		$message = "Something went wrong. Please try after some time.";
	// 	}

	// 	$message= (object) $message;
 //        $json = json_encode($message);
 //        echo $json; 
	// }

	if($_GET['action']=="fetch_all_foods"){
		$data = $restaurant->fetch_all_foods();
		if($data){
			$data= (object) $data;
	        $json = json_encode($data);
	        echo $json;
		}
		else{
			echo "Invalid request";
		}
	}

?>