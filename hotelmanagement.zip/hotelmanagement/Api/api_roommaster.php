<?php
include_once '../td_includes.php';

	$_POST = json_decode(file_get_contents('php://input'), true);

	// if($_POST['action']=="login_user"){

	// 	$userid = $_POST['userid'];
	// 	$password = $_POST['password'];

	// 	$data=$login->login_user($userid,md5($password));
	// 	if ($data) {
	// 		if($data=="Invalid Userid or Password"){
	// 			$message = "Invalid Userid or Password.";
	// 		}
	// 		else {
	// 			$_SESSION['userslug'] = $data;
	// 			$message = "Success";
	// 		}
	// 	}
	// 	else{
	// 		$message = "Something went wrong. Please try after some time.";
	// 	}

	// 	$message= (object) $message;
 //        $json = json_encode($message);
 //        echo $json; 
	// }
  

	if($_POST['action']=="save_room"){
		$id=$_POST['id'];
		$roomcategory = $_POST['roomcategory'];
		$roomtype = $_POST['roomtype'];
		$roomno = $_POST['roomno'];
		$rent = $_POST['rent'];
		$status = $_POST['status'];
		$data=$roommaster->save_room($roomcategory,$roomtype,$roomno,$rent,$status);
		if ($data) {
			$message = "Success";
		}
		else{
			$message = "Something went wrong. Please try after some time.";
		}

		$message= (object) $message;
        $json = json_encode($message);
        echo $json; 
	}

	if($_GET['action']=="fetch_all_room"){
		$data = $roommaster->fetch_all_room();
		if($data){
			$data= (object) $data;
	        $json = json_encode($data);
	        echo $json;
		}
		else{
			echo "Invalid request";
		}
	}

	if($_GET['action']=="fetch_room_detail"){
		$data = $roommaster->fetch_room_detail($_GET['id']);
		if($data){
			$data= (object) $data;
	        $json = json_encode($data);
	        echo $json;
		}
		else{
			echo "Invalid request";
		}
	}

	if($_POST['action']=="update_room"){
		
		$roomcategory = $_POST['update_roomcategory'];

		$roomtype = $_POST['update_roomtype'];
		$roomno = $_POST['update_roomno'];
		$rent = $_POST['update_rent'];
		$status = $_POST['update_status'];

		$data = $roommaster->update_room($_POST['id'],$roomcategory,$roomtype,$roomno,$rent,$status);
		if($data){
			$message="success";
			$message= (object) $message;
	        $json = json_encode($message);
	        echo $json;
		}
		
	}

	// if($_GET['action']=="fetch_customer_detail"){
	// 	$data = $customer->fetch_customer_detail($_GET['slug']);
	// 	if($data){
	// 		$data= (object) $data;
	//         $json = json_encode($data);
	//         echo $json;
	// 	}
	// 	else{
	// 		echo "Invalid request";
	// 	}
	// }

	// if($_GET['action']=="detail_customer_modal"){

	// 	$data = $customer->detailcustomer($_GET['slug']);
	// 	if($data){
	// 		$message="success";
	// 		$message= (object) $message;
	//         $json = json_encode($message);
	//         echo $json;
	// 	}
		
	// }
	

	// if($_GET['action']=="delete_customer"){

	// 	$data = $customer->delete_customer($_GET['slug']);
	// 	if($data){
	// 		$message="success";
	// 		$message= (object) $message;
	//         $json = json_encode($message);
	//         echo $json;
	// 	}
		
	// }
?>