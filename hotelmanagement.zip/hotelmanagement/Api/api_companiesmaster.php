<?php
include_once '../td_includes.php';

	$_POST = json_decode(file_get_contents('php://input'), true);

	// if($_POST['action']=="login_user"){

	// 	$userid = $_POST['userid'];
	// 	$password = $_POST['password'];

	// 	$data=$login->login_user($userid,md5($password));
	// 	if ($data) {
	// 		if($data=="Invalid Userid or Password"){
	// 			$message = "Invalid Userid or Password.";
	// 		}
	// 		else {
	// 			$_SESSION['userslug'] = $data;
	// 			$message = "Success";
	// 		}
	// 	}
	// 	else{
	// 		$message = "Something went wrong. Please try after some time.";
	// 	}

	// 	$message= (object) $message;
 //        $json = json_encode($message);
 //        echo $json; 
	// }
  

	if($_POST['action']=="save_companies"){
		$id=$_POST['id'];
		$companyname = $_POST['companyname'];
		$phone = $_POST['phone'];
		$mobile = $_POST['mobile'];
		$email = $_POST['email'];
		$address = $_POST['address'];
		$gst = $_POST['gst'];
		$data=$companiesmaster->save_companies($companyname,$phone,$mobile,$email,$address,$gst);
		if ($data) {
			$message = "Success";
		}
		else{
			$message = "Something went wrong. Please try after some time.";
		}

		$message= (object) $message;
        $json = json_encode($message);
        echo $json; 
	}

	if($_GET['action']=="fetch_all_companies"){
		$data = $companiesmaster->fetch_all_companies();
		if($data){
			$data= (object) $data;
	        $json = json_encode($data);
	        echo $json;
		}
		else{
			echo "Invalid request";
		}
	}

	if($_GET['action']=="fetch_companies_detail"){
		$data = $companiesmaster->fetch_companies_detail($_GET['id']);
		if($data){
			$data= (object) $data;
	        $json = json_encode($data);
	        echo $json;
		}
		else{
			echo "Invalid request";
		}
	}

	if($_POST['action']=="update_companies"){
		$companyname = $_POST['update_companyname'];
		$phone = $_POST['update_phone'];
		$mobile = $_POST['update_mobile'];
		$email = $_POST['update_email'];
		$address = $_POST['update_address'];
		$gst = $_POST['update_gst'];

		$data = $companiesmaster->update_companies($_POST['id'],$companyname,$phone,$mobile,$email,$address,$gst);
		if($data){
			$message="success";
			$message= (object) $message;
	        $json = json_encode($message);
	        echo $json;
		}
		
	}

	if($_GET['action']=="delete_companies"){
		$data = $companiesmaster->delete_companies($_GET['id']);
		if($data){
			$message="success";
			$message= (object) $message;
	        $json = json_encode($message);
	        echo $json;
		}
		
	}
?>