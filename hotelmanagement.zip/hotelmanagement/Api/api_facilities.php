<?php
include_once '../td_includes.php';

	$_POST = json_decode(file_get_contents('php://input'), true);

	// if($_POST['action']=="login_user"){

	// 	$userid = $_POST['userid'];
	// 	$password = $_POST['password'];

	// 	$data=$login->login_user($userid,md5($password));
	// 	if ($data) {
	// 		if($data=="Invalid Userid or Password"){
	// 			$message = "Invalid Userid or Password.";
	// 		}
	// 		else {
	// 			$_SESSION['userslug'] = $data;
	// 			$message = "Success";
	// 		}
	// 	}
	// 	else{
	// 		$message = "Something went wrong. Please try after some time.";
	// 	}

	// 	$message= (object) $message;
 //        $json = json_encode($message);
 //        echo $json; 
	// }


	if($_POST['action']=="save_facilities"){
		$slug=md5(time());
		$facilitiesname = $_POST['facilitiesname'];
		$facility = $_POST['facility'];
		$description = $_POST['description'];
		$data=$facilities->save_facilities($facilitiesname,$facility,$description,$slug);
		if ($data) {
			$message = "Success";
		}
		else{
			$message = "Something went wrong. Please try after some time.";
		}

		$message= (object) $message;
        $json = json_encode($message);
        echo $json; 
	}

	if($_GET['action']=="fetch_all_facilities"){
		$data = $facilities->fetch_all_facilities();
		if($data){
			$data= (object) $data;
	        $json = json_encode($data);
	        echo $json;
		}
		else{
			echo "Invalid request";
		}
	}


	if($_GET['action']=="delete_all_facilities"){
		$data = $facilities->delete_all_facilities($_GET['slug']);
		if($data){
			$message="success";
			$message= (object) $message;
	        $json = json_encode($message);
	        echo $json;
		}
		
	}
?>