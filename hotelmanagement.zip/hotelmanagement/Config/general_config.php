<?php 
$fileuploadurl = "../userfiles";
$uploadImageSize=51200;
$uploadVideoSize=51200;
$uploadFileSize=51200;
$profilePicSize=51200;

$sitename = "Title";

$baseurl = "http://localhost/hotelmanagement/";
$fileURL = "http://localhost/techbprjuserfiles";

// $uploadPicurl = "../../../../images/";
$Iconuploadpath="../image/";
// $IconPath="../../images/";
$imageurl = "http://localhost/hotelmanagement/image/";
$resourceSize = 51200;
// $resourcePath = "http://localhost/apna_structure/resources/";
$resourceUploadpath = "../../resources";



// $companyPrefix = "Company";

// $companyName = "";

// $email_from = "";

// $dataperpage = "5";

?>