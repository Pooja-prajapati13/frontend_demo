var tdipllp = angular.module('tdipllp', ['ui.select','ngSanitize','ngRoute','ngAnimate','ngFileUpload','ui.bootstrap','angular-toArrayFilter', 'ngTagsInput']);

var ApiUrl = "http://localhost/hotelmanagement/Api/";
var baseurl = "http://localhost/hotelmanagement/";

var site_resources = "http://localhost/hotelmanagement/resources/";

var phoneREG = /^[(]{0,1}[0-9]{3}[)\.\- ]{0,1}[0-9]{3}[\.\- ]{0,1}[0-9]{4}$/;

tdipllp.run(function($rootScope,$http,Upload,$timeout) {

});
tdipllp.filter("trust", ['$sce', function($sce) {
    return function(htmlCode){
      return $sce.trustAsHtml(htmlCode);
    }
  }]);