tdipllp.controller('roommastercontroller', ['$window', '$scope', '$http', 'Upload', '$timeout', function ($window, $scope, $http, Upload, $timeout) {

	$scope.save_room = function (roomcategory, roomtype, roomno, rent, status) {
        // status = $("#status").val();
        alert("fd"+status);

        $http({
                method: "POST",
                url: ApiUrl + 'api_roommaster.php',
                data: {
					roomcategory: roomcategory, 
                    roomtype:roomtype, 
                    roomno:roomno, 
                    rent:rent, 
                    status:status,
                    action: "save_room"
                },
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            })

            .success(function (data) {
                if (data.errors) {
                    $scope.message = "Something went wrong, please try again.";
                } else {
                    $scope.message = data.scalar;
                    if ($scope.message == "Success") {
                        $scope.fetch_all_room();
                        $scope.roomcategory = "";
                        $scope.roomtype = "";
                        $scope.roomno = "";
                        $scope.rent = "";
                        $scope.status = "";
                    } 
                    else{
                        alert($scope.message);
                    }
                }
            })
	} 

     

    $scope.fetch_all_room = function(){
        $http.get(ApiUrl+"api_roommaster.php?action=fetch_all_room")
        .success(function(allroom){
            if(allroom==null || allroom==undefined || allroom=="Invalid request"){
                $scope.allroom = "";
            }
            else{
                $scope.allroom = allroom;
            }
        })
    }
    $scope.fetch_all_room();

    

    $scope.fetch_room_detail= function(id){

        $http.get(ApiUrl+"api_roommaster.php?action=fetch_room_detail&id="+id)
        .success(function(roomdetail){              
           if(roomdetail==null || roomdetail==undefined || roomdetail=="Invalid request"){
                $scope.roomdetail = "";
            }
         else{
            
            $scope.id = id;          
            $scope.update_roomcategory = roomdetail.roomcategory;
            $scope.update_roomtype = roomdetail.roomtype;
            $scope.update_roomno = roomdetail.roomno;
            $scope.update_rent = roomdetail.rent; 
            $scope.update_status = roomdetail.status;

        }
    })
    }
    $scope.update_room_modal = function(id){ 
        $scope.roomid=id;
        $scope.fetch_room_detail(id);
        $('#updateroom').modal('toggle');
    }
    $scope.update_room = function(id,update_roomcategory, update_roomtype, update_roomno, update_rent, update_status){
        // alert("ad"+id);
                $http({
                method: "POST",
                url: ApiUrl + 'api_roommaster.php',
                data: {
                    id: id,
                    update_roomcategory: update_roomcategory,
                    update_roomtype:update_roomtype, 
                    update_roomno:update_roomno, 
                    update_rent:update_rent, 
                    update_status:update_status,
                    action: "update_room"
                },
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            })
            .success(function (data) {
                // console.log(data);
                if (data.errors) {
                    $scope.message = "Something went wrong, please try again.";
                } else {
                    $scope.message = data.scalar;
                    if ($scope.message == "Success") {

                        $scope.update_roomcategory = "";
                        $scope.update_roomtype = "";
                        $scope.update_roomno = "";
                        $scope.update_rent = "";
                        $scope.update_status = "";
                        $scope.fetch_room_detail();

                    } 
                    else{
                        alert($scope.message);
                    }
                }
            })
    }

    // $scope.fetch_customer_detail = function(slug){
    //     $http.get(ApiUrl+"api_customer.php?action=fetch_customer_detail&slug="+slug)
    //     .success(function(customerdetail){
    //         if(customerdetail==null || customerdetail==undefined || customerdetail=="Invalid request"){
    //             $scope.customerdetail = "";
    //         }
    //      else{
            
    //         $scope.slug = slug; 
    //         $scope.code = customerdetail.code;
    //         $scope.status = customerdetail.status;
    //         $scope.bookingtime = customerdetail.bookingtime;
    //         $scope.checkin = customerdetail.checkin;
    //         $scope.checkout = customerdetail.checkout;
    //         $scope.adultno = customerdetail.adultno;
    //         $scope.childno = customerdetail.childno;
    //         $scope.infantno = customerdetail.infantno;
    //         $scope.room = customerdetail.room;
    //         $scope.roomfacilities = customerdetail.roomfacilities;
    //         $scope.yourbudget = customerdetail.yourbudget;
    //         $scope.meals = customerdetail.meals;
    //         $scope.bedpreference = customerdetail.bedpreference;
    //         $scope.guestname = customerdetail.guestname;
    //         $scope.company = customerdetail.company;
    //         $scope.email = customerdetail.email;
    //         $scope.phone = customerdetail.phone;
    //         $scope.specialrequirement = customerdetail.specialrequirement;
    //         $scope.address = customerdetail.address;
    //         $scope.city = customerdetail.city;
    //         $scope.country = customerdetail.country;
    //         $scope.state = customerdetail.state;
    //         $scope.postcode = customerdetail.postcode;
    //         $scope.roomtotal = customerdetail.roomtotal;
    //         $scope.discount = customerdetail.discount;
    //         $scope.totalamount = customerdetail.totalamount;
    //         $scope.servicetotal = customerdetail.servicetotal;
    //         $scope.tax = customerdetail.tax;
    //         $scope.paid = customerdetail.paid;
    //         $scope.nettotal = customerdetail.nettotal;
    //         $scope.taxtotal = customerdetail.taxtotal;
    //         $scope.balance = customerdetail.balance;

    //     }
           
            
    //     })
        
    // }

    // $scope.detail_customer_modal = function(slug){ 
    //     $scope.sluggg=slug;
    //     $scope.fetch_customer_detail(slug);
    //     $('#detailcustomer').modal('toggle');
    // }

   



    // $scope.delete_customer_modal = function(slug){
        
    //     $scope.slugg=slug;
    //     $('#deletecustomer').modal('toggle');
    // }
    
    // $scope.delete_customer = function(slug){
    //     // alert("ad"+slug);
    //     $http.get(ApiUrl+"api_customer.php?action=delete_customer&slug="+slug)
    //     .success(function(slug){
    //        $scope.fetch_all_customer();
    //        $('#deletecustomer').modal('toggle');
            
    //     })
    // }

}]);