tdipllp.controller('logincontroller', ['$window', '$scope', '$http', 'Upload', '$timeout', function ($window, $scope, $http, Upload, $timeout) {

    $scope.save_login = function (userid, password) {
        // status = $("#status").val();
        //alert("fd"+status);

        $http({
                method: "POST",
                url: ApiUrl + 'api_login.php',
                data: {
                     
                    userid:userid, 
                    password:password,
                    action: "save_login"
                },
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            })

            .success(function (data) {
                console.log(data);

                if (data.errors) {
                    $scope.message = "Something went wrong, please try again.";
                } else {
                      window.location.replace("/hotelmanagement/Dashboard");
                    
                }
            })
    } 



$scope.logout = function () {


        $http({
                method: "POST",
                url: ApiUrl + 'api_login.php',
                data: {
                     
                    
                    action: "logout"
                },
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            })

            .success(function (data) {
                console.log(data);

                if (data.errors) {
                    $scope.message = "Something went wrong, please try again.";
                } else {
                      window.location.replace("/hotelmanagement/login");
                    
                }
            })
    } 


}]);