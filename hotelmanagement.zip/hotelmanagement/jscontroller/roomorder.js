tdipllp.controller('roomordercontroller', ['$window', '$scope', '$http', 'Upload', '$timeout', function ($window, $scope, $http, Upload, $timeout) {
 $scope.slug=slug;
    $scope.add_order = function (service,rate,quantity,total,is_free ) {
        $http({
                method: "POST",
                url: ApiUrl + 'api_roomorder.php',
                data: {

                    service: service,
                    rate: rate,
                    quantity: quantity,
                    total: total,
                    is_free:is_free,
                    slug:slug,
                    action: "add_order"
                },
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            })
            .success(function (data) {
                if (data.errors) {
                    $scope.message = "Something went wrong, please try again.";
                } else {
                    $scope.message = data.scalar;
                    if ($scope.message == "Success") {
                        $scope.fetch_all_order(slug);
                        $scope.service = "";
                        $scope.rate = "";
                        $scope.quantity = "";
                        $scope.total = "";
                        $scope.is_free = "";
                        // $("#restomember").modal("toggle");
                    } 
                    else{
                        alert($scope.message);
                    }
                }
            })
    } 

    $scope.fetch_all_order = function(slug){
        $http.get(ApiUrl+"api_roomorder.php?action=fetch_all_order&registeration_no="+ $scope.slug)
        .success(function(allorder){
            if(allorder==null || allorder==undefined || allorder=="Invalid request"){
                $scope.allorder = "";
            }
            else{
                $scope.allorder = allorder;
            }
        })
    }

    $scope.fetch_all_order();

}]);