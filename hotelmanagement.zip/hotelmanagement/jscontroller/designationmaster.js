tdipllp.controller('designationmastercontroller', ['$window', '$scope', '$http', 'Upload', '$timeout', function ($window, $scope, $http, Upload, $timeout) {

    $scope.save_designation = function (designation_name, designation_status) {
        // status = $("#status").val();
        alert("fd"+status);

        $http({
                method: "POST",
                url: ApiUrl + 'api_designationmaster.php',
                data: {
                    designation_name: designation_name, 
                    designation_status:designation_status,
                    action: "save_designation"
                },
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            })

            .success(function (data) {
                if (data.errors) {
                    $scope.message = "Something went wrong, please try again.";
                } else {
                    $scope.message = data.scalar;
                    if ($scope.message == "Success") {
                        $scope.fetch_all_designation();
                        $scope.designation_name = "";
                        $scope.designation_status = "";
                    } 
                    else{
                        alert($scope.message);
                    }
                }
            })
    } 

    $scope.fetch_all_designation = function(){
        $http.get(ApiUrl+"api_designationmaster.php?action=fetch_all_designation")
        .success(function(alldesignation){
            if(alldesignation==null || alldesignation==undefined || alldesignation=="Invalid request"){
                $scope.alldesignation = "";
            }
            else{
                $scope.alldesignation = alldesignation;
            }
        })
    }
    $scope.fetch_all_designation();


    $scope.fetch_designation_detail= function(id){

        $http.get(ApiUrl+"api_designationmaster.php?action=fetch_designation_detail&id="+id)
        .success(function(designationdetail){              
           if(designationdetail==null || designationdetail==undefined || designationdetail=="Invalid request"){
                $scope.designationdetail = "";
            }
         else{
            
            $scope.id = id;          
            $scope.update_designation_name= designationdetail.designation_name; 
            $scope.update_designation_status = designationdetail.designation_status;

        }
    })
    }
    $scope.update_designation_modal = function(id){ 
        $scope.designationid=id;
        $scope.fetch_designation_detail(id);
        $('#updatedesignation').modal('toggle');
    }
    $scope.update_designation = function(id,update_designation_name, update_designation_status){
        // alert("ad"+id);
                $http({
                method: "POST",
                url: ApiUrl + 'api_designationmaster.php',
                data: {
                    id: id,
                    update_designation_name: update_designation_name, 
                    update_designation_status:update_designation_status,
                    action: "update_designation"
                },
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            })
            .success(function (data) {
                // console.log(data);
                if (data.errors) {
                    $scope.message = "Something went wrong, please try again.";
                } else {
                    $scope.message = data.scalar;
                    if ($scope.message == "Success") {

                        $scope.update_designation_name = "";
                        $scope.update_designation_status = "";
                        $scope.fetch_designation_detail();

                    } 
                    else{
                        alert($scope.message);
                    }
                }
            })
    }

    $scope.delete_designation_modal = function(id){
        // alert ("ad"+id);
        $scope.id=id;
        $('#deletedesignation').modal('toggle');
    }
    
    $scope.delete_designation = function(id){
        alert("ad"+id);
        $http.get(ApiUrl+"api_designationmaster.php?action=delete_designation&id="+id)
        .success(function(id){
           $scope.fetch_all_designation();
           $('#deletedesignation').modal('toggle');
            
        })
    }
    


}]);