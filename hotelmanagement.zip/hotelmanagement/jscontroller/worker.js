tdipllp.controller('workercontroller', ['$window', '$scope', '$http', 'Upload', '$timeout', function ($window, $scope, $http, Upload, $timeout) {

	$scope.add_member = function (name, mobileno, email, address, designation, workexperience, joiningdate, salary ) {
        $http({
                method: "POST",
                url: ApiUrl + 'api_worker.php',
                data: {

					name: name,
                    mobileno: mobileno,
                    email: email,
                    address: address,
                    designation: designation,
                    workexperience: workexperience,
                    joiningdate: joiningdate,
                    salary: salary,
                    action: "add_member"
                },
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            })
            .success(function (data) {
                if (data.errors) {
                    $scope.message = "Something went wrong, please try again.";
                } else {
                    $scope.message = data.scalar;
                    if ($scope.message == "Success") {
                        $scope.fetch_all_members();
                        $scope.name = "";
                        $scope.mobileno = "";
                        $scope.email = "";
                        $scope.address = "";
                        $scope.designation = "";
                        $scope.workexperience = "";
                        $scope.joiningdate = "";
                        $scope.salary = "";
                        $("#addmember").modal("toggle");
                    } 
                    else{
                        alert($scope.message);
                    }
                }
            })
	} 

    $scope.fetch_all_members = function(){
        $http.get(ApiUrl+"api_worker.php?action=fetch_all_members")
        .success(function(allmembers){
            if(allmembers==null || allmembers==undefined || allmembers=="Invalid request"){
                $scope.allmembers = "";
            }
            else{
                $scope.allmembers = allmembers;
            }
        })
    }

    $scope.fetch_all_members();

}]);