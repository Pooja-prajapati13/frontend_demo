tdipllp.controller('registerationcontroller', ['$window', '$scope', '$http', 'Upload', '$timeout', function ($window, $scope, $http, Upload, $timeout) {

	$scope.check_in = function (registeration_no, arrival_date, arrival_time, occupy, guest_name, company_name, company_gst, no_of_person, mobile, room_rent, advance, reference, room_no, file, guest_id, permanent_address, nationality) {
        // status = $("#status").val();
        alert("fd"+status);

        $http({
                method: "POST",
                url: ApiUrl + 'api_registeration.php',
                data: {
					registeration_no: registeration_no,
                    arrival_date: arrival_date,
                    arrival_time: arrival_time, 
                    occupy: occupy, 
                    guest_name: guest_name, 
                    company_name: company_name,
                    company_gst: company_gst, 
                    no_of_person: no_of_person, 
                    mobile: mobile, 
                    room_rent: room_rent, 
                    advance: advance, 
                    reference: reference, 
                    room_no: room_no, 
                    file: file, 
                    guest_id: guest_id, 
                    permanent_address: permanent_address, 
                    nationality: nationality,
                    action: "check_in"
                },
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            })

            .success(function (data) {
                if (data.errors) {
                    $scope.message = "Something went wrong, please try again.";
                } else {
                    $scope.message = data.scalar;
                    if ($scope.message == "Success") {
                     window.location.replace("/hotelmanagement/Dashboard");
                        // $scope.fetch_all_booking();
                        $scope.registeration_no = "";
                        $scope.arrival_date = "";
                        $scope.arrival_time = "";
                        $scope.occupy = "";
                        $scope.guest_name = "";
                        $scope.company_name = "";
                        $scope.company_gst = "";
                        $scope.no_of_person = "";
                        $scope.mobile = "";
                        $scope.room_rent = "";
                        $scope.advance = "";
                        $scope.reference = "";
                        $scope.room_no = "";
                        $scope.file = "";
                        $scope.guest_id = "";
                        $scope.permanent_address = "";
                        $scope.nationality = "";
                    } 
                    else{
                        alert($scope.message);
                    }
                }
            })
	} 

    // $scope.fetch_all_customer = function(){
    //     $http.get(ApiUrl+"api_customer.php?action=fetch_all_customer")
    //     .success(function(allcustomer){
    //         if(allcustomer==null || allcustomer==undefined || allcustomer=="Invalid request"){
    //             $scope.allcustomer = "";
    //         }
    //         else{
    //             $scope.allcustomer = allcustomer;
    //         }
    //     })
    // }
    // $scope.fetch_all_customer();

    // $scope.fetch_customer_detail = function(slug){
    //     $http.get(ApiUrl+"api_customer.php?action=fetch_customer_detail&slug="+slug)
    //     .success(function(customerdetail){
    //         if(customerdetail==null || customerdetail==undefined || customerdetail=="Invalid request"){
    //             $scope.customerdetail = "";
    //         }
    //      else{
            
    //         $scope.slug = slug; 
    //         $scope.code = customerdetail.code;
    //         $scope.status = customerdetail.status;
    //         $scope.bookingtime = customerdetail.bookingtime;
    //         $scope.checkin = customerdetail.checkin;
    //         $scope.checkout = customerdetail.checkout;
    //         $scope.adultno = customerdetail.adultno;
    //         $scope.childno = customerdetail.childno;
    //         $scope.infantno = customerdetail.infantno;
    //         $scope.room = customerdetail.room;
    //         $scope.roomfacilities = customerdetail.roomfacilities;
    //         $scope.yourbudget = customerdetail.yourbudget;
    //         $scope.meals = customerdetail.meals;
    //         $scope.bedpreference = customerdetail.bedpreference;
    //         $scope.guestname = customerdetail.guestname;
    //         $scope.company = customerdetail.company;
    //         $scope.email = customerdetail.email;
    //         $scope.phone = customerdetail.phone;
    //         $scope.specialrequirement = customerdetail.specialrequirement;
    //         $scope.address = customerdetail.address;
    //         $scope.city = customerdetail.city;
    //         $scope.country = customerdetail.country;
    //         $scope.state = customerdetail.state;
    //         $scope.postcode = customerdetail.postcode;
    //         $scope.roomtotal = customerdetail.roomtotal;
    //         $scope.discount = customerdetail.discount;
    //         $scope.totalamount = customerdetail.totalamount;
    //         $scope.servicetotal = customerdetail.servicetotal;
    //         $scope.tax = customerdetail.tax;
    //         $scope.paid = customerdetail.paid;
    //         $scope.nettotal = customerdetail.nettotal;
    //         $scope.taxtotal = customerdetail.taxtotal;
    //         $scope.balance = customerdetail.balance;

    //     }
           
            
    //     })
        
    // }

    // $scope.detail_customer_modal = function(slug){ 
    //     $scope.sluggg=slug;
    //     $scope.fetch_customer_detail(slug);
    //     $('#detailcustomer').modal('toggle');
    // }

   



    // $scope.delete_customer_modal = function(slug){
        
    //     $scope.slugg=slug;
    //     $('#deletecustomer').modal('toggle');
    // }
    
    // $scope.delete_customer = function(slug){
    //     // alert("ad"+slug);
    //     $http.get(ApiUrl+"api_customer.php?action=delete_customer&slug="+slug)
    //     .success(function(slug){
    //        $scope.fetch_all_customer();
    //        $('#deletecustomer').modal('toggle');
            
    //     })
    // }

}]);