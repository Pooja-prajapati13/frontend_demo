// $scope.add_food=function(foodname, category, file , price){
//         file.upload = Upload.upload({                  
//             method: 'POST',
//             url: ApiUrl+'api_media_controller.php',
//             data: { 
//                 foodname:foodname,
//                 category:category,
//                 file: file,
//                 price:price,
//                 action:"add_food",
//             }                  
//         }).then(function (resp) {
//             $scope.foodname = "";
//             $scope.category = "";
//             $scope.file = "";
//             $scope.price = "";
//             alert("Data uploaded successfully")
//             $('#fooditem').modal('toggle');
//             $scope.fetch_all_restaurant();
            

//         }); 

//         file.upload.then(function (resp) {
//             $timeout(function () {
//                 file.result = resp;
//             });
//         }, function (resp) {
//             alert("something went wrong please try again.");
//         }, function (evt) {
//             file.progress = Math.min(100, parseInt(100.0 * evt.loaded / evt.total));
//         });
//     }