tdipllp.controller('roomscontroller', ['$window', '$scope', '$http', 'Upload', '$timeout', function ($window, $scope, $http, Upload, $timeout) {
        // $scope.slugg=slug;
 
    $scope.save_rooms = function (roomno, floor, type, price) {
        $http({
                method: "POST",
                url: ApiUrl + 'api_rooms.php',
                data: {
                    roomno: roomno,
                    floor: floor,
                    type: type,
                    price: price,
                    action: "save_rooms"
                },
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            })
            .success(function (data) {
                if (data.errors) {
                    $scope.message = "Something went wrong, please try again.";
                } else {
                    $scope.message = data.scalar;
                    if ($scope.message == "Success") {
                        $scope.fetch_all_rooms();
                        $scope.roomno = "";
                        $scope.floor = "";
                        $scope.type = "";
                        $scope.price = "";
                    } 
                    else{
                        alert($scope.message);
                    }
                }
            })
    } 

    $scope.fetch_all_rooms = function(){
        $http.get(ApiUrl+"api_rooms.php?action=fetch_all_rooms")
        .success(function(allrooms){
            if(allrooms==null || allrooms==undefined || allrooms=="Invalid request"){
                $scope.allrooms = "";
            }
            else{
                $scope.allrooms = allrooms;
            }
        })
    }

    $scope.fetch_all_rooms();

   $scope.delete_room_modal = function(slug){
        
        $scope.slugg=slug;
        $('#deleteRoom').modal('toggle');
    }
    
    $scope.delete_room = function(slug){
        // alert("ad"+slug);
        $http.get(ApiUrl+"api_rooms.php?action=delete_all_room&slug="+slug)
        .success(function(slug){
           $scope.fetch_all_rooms();
           $('#deleteRoom').modal('toggle');
            
        })
    }
    
    $scope.fetch_room_detail= function(slug){

        $http.get(ApiUrl+"api_rooms.php?action=fetch_room_detail&slug="+slug)
        .success(function(roomdetail){              
           if(roomdetail==null || roomdetail==undefined || roomdetail=="Invalid request"){
                $scope.roomdetail = "";
            }
         else{
            
            $scope.slug = slug;          
            $scope.room = roomdetail.roomno;
            $scope.flr = roomdetail.floor;
            $scope.typ = roomdetail.type;
            $scope.pric = roomdetail.price; 
           

        }
    })
    }

        


        

    $scope.add_image=function(image1,image2,image3,image4,image5,image6,slug ){
        // alert("ad"+slug+image1+image2+image3+image4+image5+image6);

        const file=[image1,image2,image3,image4,image5,image6,];

        // alert('a'+file);
        file.upload = Upload.upload({                  
            method: 'POST',
            url: ApiUrl+'api_media.php',
            data: { 
                slug :slug,
                file:file,
                action:"add_image",
            }                  
        }).then(function (resp) {

            // $scope.image1 = "";
            // $scope.image2 = "";
            // $scope.image3 = "";
            // $scope.image4 = "";
            // $scope.image5 = "";
            // $scope.image6 = "";
            alert("Data uploaded successfully")
            
            $('#detailRoom').modal('toggle');
            $scope.detail_room_modal();
            

        }); 

        file.upload.then(function (resp) {
            $timeout(function () {
                file.result = resp;
            });
            
        }, function (resp) {
            alert("something went wrong please try again.");
        }, function (evt) {
            file.progress = Math.min(100, parseInt(100.0 * evt.loaded / evt.total));
        });
    }
    $scope.detail_room_modal = function(slug){
        
        $scope.slugg=slug;

        $('#detailRoom').modal('toggle');
    }

    $scope.view_room_modal = function(slug,type){
       
        $scope.slug=slug;
        $('#viewroom').modal('toggle');
        $scope.fetch_image(slug);
        $scope.fetch_facilities(type);
    }
   

    $scope.fetch_facilities = function(type){
        $http.get(ApiUrl+"api_rooms.php?action=fetch_facilities&type="+type)
        .success(function(facilities){
            if(facilities==null || facilities==undefined || facilities=="Invalid request"){
                $scope.facilities = "";
            }
            else{
                $scope.facilities = facilities;
            }
        })
    }

     $scope.fetch_image = function(slug, roomslug, imagename){
        $http.get(ApiUrl+"api_rooms.php?action=fetch_image&slug="+slug)
        .success(function(image){
            if(image==null || image==undefined || image=="Invalid request"){
                $scope.image = "";
            }
            else{
                $scope.image = image;
            }
        })
    }
        $scope.fetch_image();

    
    

     $scope.update_room_modal = function(slug){ 
        $scope.slugg=slug;
        $scope.fetch_room_detail(slug);
        $('#updateRoom').modal('toggle');
    }

    
    $scope.update_room = function(slug,room, flr, typ, pric){
        // alert("ad"+slug);
                $http({
                method: "POST",
                url: ApiUrl + 'api_rooms.php',
                data: {
                    slug: slug,
                    room: room,
                    flr: flr,
                    typ: typ,
                    pric: pric,
                    action: "update_room"
                },
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            })
            .success(function (data) {
                if (data.errors) {
                    $scope.message = "Something went wrong, please try again.";
                } else {
                    $scope.message = data.scalar;
                    if ($scope.message == "Success") {

                        $scope.room = "";
                        $scope.flr = "";
                        $scope.typ = "";
                        $scope.pric = "";
                        $scope.fetch_room_detail();

                    } 
                    else{
                        alert($scope.message);
                    }
                }
            })
    }
}]);