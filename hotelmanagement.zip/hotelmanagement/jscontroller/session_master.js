tdipllp.controller('session_mastercontroller', ['$window', '$scope', '$http', 'Upload', '$timeout', function ($window, $scope, $http, Upload, $timeout) {

    $scope.save_session = function (session_name, from_date, to_date) {
        // status = $("#status").val();
        alert("fd"+status);

        $http({
                method: "POST",
                url: ApiUrl + 'api_session_master.php',
                data: {
                    session_name: session_name, 
                    from_date:from_date, 
                    to_date:to_date,
                    action: "save_session"
                },
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            })

            .success(function (data) {
                if (data.errors) {
                    $scope.message = "Something went wrong, please try again.";
                } else {
                    $scope.message = data.scalar;
                    if ($scope.message == "Success") {
                        // $scope.fetch_all_booking();
                        $scope.session_name = "";
                        $scope.from_date = "";
                        $scope.to_date = "";
                    } 
                    else{
                        alert($scope.message);
                    }
                }
            })
    } 

    // $scope.fetch_all_customer = function(){
    //     $http.get(ApiUrl+"api_customer.php?action=fetch_all_customer")
    //     .success(function(allcustomer){
    //         if(allcustomer==null || allcustomer==undefined || allcustomer=="Invalid request"){
    //             $scope.allcustomer = "";
    //         }
    //         else{
    //             $scope.allcustomer = allcustomer;
    //         }
    //     })
    // }
    // $scope.fetch_all_customer();

    // $scope.fetch_customer_detail = function(slug){
    //     $http.get(ApiUrl+"api_customer.php?action=fetch_customer_detail&slug="+slug)
    //     .success(function(customerdetail){
    //         if(customerdetail==null || customerdetail==undefined || customerdetail=="Invalid request"){
    //             $scope.customerdetail = "";
    //         }
    //      else{
            
    //         $scope.slug = slug; 
    //         $scope.code = customerdetail.code;
    //         $scope.status = customerdetail.status;
    //         $scope.bookingtime = customerdetail.bookingtime;
    //         $scope.checkin = customerdetail.checkin;
    //         $scope.checkout = customerdetail.checkout;
    //         $scope.adultno = customerdetail.adultno;
    //         $scope.childno = customerdetail.childno;
    //         $scope.infantno = customerdetail.infantno;
    //         $scope.room = customerdetail.room;
    //         $scope.roomfacilities = customerdetail.roomfacilities;
    //         $scope.yourbudget = customerdetail.yourbudget;
    //         $scope.meals = customerdetail.meals;
    //         $scope.bedpreference = customerdetail.bedpreference;
    //         $scope.guestname = customerdetail.guestname;
    //         $scope.company = customerdetail.company;
    //         $scope.email = customerdetail.email;
    //         $scope.phone = customerdetail.phone;
    //         $scope.specialrequirement = customerdetail.specialrequirement;
    //         $scope.address = customerdetail.address;
    //         $scope.city = customerdetail.city;
    //         $scope.country = customerdetail.country;
    //         $scope.state = customerdetail.state;
    //         $scope.postcode = customerdetail.postcode;
    //         $scope.roomtotal = customerdetail.roomtotal;
    //         $scope.discount = customerdetail.discount;
    //         $scope.totalamount = customerdetail.totalamount;
    //         $scope.servicetotal = customerdetail.servicetotal;
    //         $scope.tax = customerdetail.tax;
    //         $scope.paid = customerdetail.paid;
    //         $scope.nettotal = customerdetail.nettotal;
    //         $scope.taxtotal = customerdetail.taxtotal;
    //         $scope.balance = customerdetail.balance;

    //     }
           
            
    //     })
        
    // }

    // $scope.detail_customer_modal = function(slug){ 
    //     $scope.sluggg=slug;
    //     $scope.fetch_customer_detail(slug);
    //     $('#detailcustomer').modal('toggle');
    // }

   



    // $scope.delete_customer_modal = function(slug){
        
    //     $scope.slugg=slug;
    //     $('#deletecustomer').modal('toggle');
    // }
    
    // $scope.delete_customer = function(slug){
    //     // alert("ad"+slug);
    //     $http.get(ApiUrl+"api_customer.php?action=delete_customer&slug="+slug)
    //     .success(function(slug){
    //        $scope.fetch_all_customer();
    //        $('#deletecustomer').modal('toggle');
            
    //     })
    // }

}]);