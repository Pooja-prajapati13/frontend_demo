tdipllp.controller('employeemastercontroller', ['$window', '$scope', '$http', 'Upload', '$timeout', function ($window, $scope, $http, Upload, $timeout) {

    $scope.save_employee_master = function(employee_name, designation_name, employee_status) {
        // status = $("#status").val();
        alert("fd"+status);

        $http({
                method: "POST",
                url: ApiUrl + 'api_employeemaster.php',
                data: {
                    employee_name: employee_name, 
                    designation_name:designation_name, 
                    employee_status:employee_status,
                    action: "save_employee_master"
                },
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            })

            .success(function (data) {
                if (data.errors) {
                    $scope.message = "Something went wrong, please try again.";
                } else {
                    $scope.message = data.scalar;
                    if ($scope.message == "Success") {
                        $scope.fetch_all_employee();
                        $scope.employee_name = "";
                        $scope.designation_name = "";
                        $scope.employee_status = "";
                    } 
                    else{
                        alert($scope.message);
                    }
                }
            })
    } 
    $scope.fetch_all_employee = function(){
        $http.get(ApiUrl+"api_employeemaster.php?action=fetch_all_employee")
        .success(function(allemployee){
            if(allemployee==null || allemployee==undefined || allemployee=="Invalid request"){
                $scope.allemployee = "";
            }
            else{
                $scope.allemployee = allemployee;
            }
        })
    }
    $scope.fetch_all_employee();


    $scope.fetch_employee_detail= function(id){

        $http.get(ApiUrl+"api_employeemaster.php?action=fetch_employee_detail&id="+id)
        .success(function(employeedetail){              
           if(employeedetail==null || employeedetail==undefined || employeedetail=="Invalid request"){
                $scope.employeedetail = "";
            }
         else{
            
            $scope.id = id;          
            $scope.update_employee_name= employeedetail.employee_name;
            $scope.update_designation_name= employeedetail.designation_name; 
            $scope.update_employee_status = employeedetail.employee_status;

        }
    })
    }
    $scope.update_employee_modal = function(id){ 
        $scope.employeeid=id;
        $scope.fetch_employee_detail(id);
        $('#updateemployee').modal('toggle');
    }
    $scope.update_employee = function(id,update_employee_name,update_designation_name, update_employee_status){
        // alert("ad"+id);
                $http({
                method: "POST",
                url: ApiUrl + 'api_employeemaster.php',
                data: {
                    id: id,
                    update_employee_name: update_employee_name,
                    update_designation_name: update_designation_name, 
                    update_employee_status:update_employee_status,
                    action: "update_employee"
                },
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            })
            .success(function (data) {
                // console.log(data);
                if (data.errors) {
                    $scope.message = "Something went wrong, please try again.";
                } else {
                    $scope.message = data.scalar;
                    if ($scope.message == "Success") {

                        $scope.update_employee_name = "";
                        $scope.update_designation_name = "";
                        $scope.update_employee_status = "";
                        $scope.fetch_employee_detail();

                    } 
                    else{
                        alert($scope.message);
                    }
                }
            })
    }

    $scope.delete_employee_modal = function(id){
        // alert ("ad"+id);
        $scope.id=id;
        $('#deleteemployee').modal('toggle');
    }
    
    $scope.delete_employee = function(id){
        alert("ad"+id);
        $http.get(ApiUrl+"api_employeemaster.php?action=delete_employee&id="+id)
        .success(function(id){
           $scope.fetch_all_employee();
           $('#deleteemployee').modal('toggle');
            
        })
    }
    

}]);