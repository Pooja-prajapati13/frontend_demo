tdipllp.controller('facilitiescontroller', ['$window', '$scope', '$http', 'Upload', '$timeout', function ($window, $scope, $http, Upload, $timeout) {

	$scope.save_facilities = function ( facilitiesname, facility, description) {
         // alert("fd"+facility);
        $http({
                method: "POST",
                url: ApiUrl + 'api_facilities.php',
                data: {

					facilitiesname: facilitiesname,
                    facility: facility, 
                    description: description,
                   
                    action: "save_facilities"
                },
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            })
            .success(function (data) {
                if (data.errors) {
                    $scope.message = "Something went wrong, please try again.";
                } else {
                    $scope.message = data.scalar;
                    if ($scope.message == "Success") {
                     
                        $scope.fetch_all_facilities();  
                        $scope.facilitiesname = "";
                        $scope.facility = "";
                        $scope.description = "";    
                    } 
                    else{
                        alert($scope.message);
                    }
                }
            })
	} 


    $scope.fetch_all_facilities = function(){
        $http.get(ApiUrl+"api_facilities.php?action=fetch_all_facilities")
        .success(function(allfacilities){
            if(allfacilities==null || allfacilities==undefined || allfacilities=="Invalid request"){
                $scope.allfacilities = "";
            }
            else{
                $scope.allfacilities = allfacilities;
            }
        })
    }

    $scope.fetch_all_facilities();

    $scope.delete_all_facilities = function(){
        $http.get(ApiUrl+"api_facilities.php?action=delete_all_facilities")
        .success(function(allfacilities){
            if(allfacilities==null || allfacilities==undefined || allfacilities=="Invalid request"){
                $scope.allfacilities = "";
            }
            else{
                $scope.allfacilities = allfacilities;
            }
        })
    }

    $scope.delete_facilities_modal = function(slug){
        
        $scope.slugg=slug;
        $('#deletefacilities').modal('toggle');
    }
    
    $scope.delete_facilities = function(slug){
        // alert("ad"+slug);
        $http.get(ApiUrl+"api_facilities.php?action=delete_all_facilities&slug="+slug)
        .success(function(slug){
           $scope.fetch_all_facilities();
           $('#deletefacilities').modal('toggle');
            
        })
    }
   
    // $scope.delete = function(facilitiesname, facility, description){
    //     // var subject = // get subject somehow ...
    //     that = this;
    //     $http.get(ApiUrl+"delete.php?subject=" + subject)
    //     .success(function(data){
    //    $scope.users.splice(that.$index, 1)
    // })
    // }



}]);