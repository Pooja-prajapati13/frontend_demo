tdipllp.controller('companiesmastercontroller', ['$window', '$scope', '$http', 'Upload', '$timeout', function ($window, $scope, $http, Upload, $timeout) {

    $scope.save_companies = function (companyname, phone, mobile, email, address, gst) {
        // status = $("#status").val();
        alert("fd"+status);

        $http({
                method: "POST",
                url: ApiUrl + 'api_companiesmaster.php',
                data: {
                    companyname: companyname, 
                    phone:phone, 
                    mobile:mobile, 
                    email:email, 
                    address:address,
                    gst:gst,
                    action: "save_companies"
                },
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            })

            .success(function (data) {
                if (data.errors) {
                    $scope.message = "Something went wrong, please try again.";
                } else {
                    $scope.message = data.scalar;
                    if ($scope.message == "Success") {
                        $scope.fetch_all_companies();
                        $scope.companyname = "";
                        $scope.phone = "";
                        $scope.mobile = "";
                        $scope.email = "";
                        $scope.address = "";
                        $scope.gst = "";
                    } 
                    else{
                        alert($scope.message);
                    }
                }
            })
    } 

    $scope.fetch_all_companies = function(){
        $http.get(ApiUrl+"api_companiesmaster.php?action=fetch_all_companies")
        .success(function(allcompanies){
            if(allcompanies==null || allcompanies==undefined || allcompanies=="Invalid request"){
                $scope.allcompanies = "";
            }
            else{
                $scope.allcompanies = allcompanies;
            }
        })
    }
    $scope.fetch_all_companies();


    $scope.fetch_companies_detail= function(id){

        $http.get(ApiUrl+"api_companiesmaster.php?action=fetch_companies_detail&id="+id)
        .success(function(companiesdetail){              
           if(companiesdetail==null || companiesdetail==undefined || companiesdetail=="Invalid request"){
                $scope.companiesdetail = "";
            }
         else{
            
            $scope.id = id;          
            $scope.update_companyname= companiesdetail.companyname; 
            $scope.update_phone = companiesdetail.phone;
            $scope.update_mobile = companiesdetail.mobile;
            $scope.update_email = companiesdetail.email;
            $scope.update_address = companiesdetail.address;
            $scope.update_gst = companiesdetail.gst;

        }
    })
    }
    $scope.update_companies_modal = function(id){ 
        $scope.companiesid=id;
        $scope.fetch_companies_detail(id);
        $('#updatecompanies').modal('toggle');
    }
    $scope.update_companies = function(id,update_companyname, update_phone, update_mobile, update_email, update_address, update_gst){
        // alert("ad"+id);
                $http({
                method: "POST",
                url: ApiUrl + 'api_companiesmaster.php',
                data: {
                    id: id,
                    update_companyname: update_companyname, 
                    update_phone:update_phone,
                    update_mobile: update_mobile, 
                    update_email:update_email,
                    update_address: update_address, 
                    update_gst:update_gst,
                    action: "update_companies"
                },
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            })
            .success(function (data) {
                // console.log(data);
                if (data.errors) {
                    $scope.message = "Something went wrong, please try again.";
                } else {
                    $scope.message = data.scalar;
                    if ($scope.message == "Success") {

                        $scope.update_companyname = "";
                        $scope.update_phone = "";
                        $scope.update_mobile = "";
                        $scope.update_email = "";
                        $scope.update_address = "";
                        $scope.update_gst = "";
                        $scope.fetch_companies_detail();

                    } 
                    else{
                        alert($scope.message);
                    }
                }
            })
    }

    $scope.delete_companies_modal = function(id){
        // alert ("ad"+id);
        $scope.id=id;
        $('#deletecompanies').modal('toggle');
    }
    
    $scope.delete_companies = function(id){
        alert("ad"+id);
        $http.get(ApiUrl+"api_companiesmaster.php?action=delete_companies&id="+id)
        .success(function(id){
           $scope.fetch_all_companies();
           $('#deletecompanies').modal('toggle');
            
        })
    }

}]);