tdipllp.controller('restostaffcontroller', ['$window', '$scope', '$http', 'Upload', '$timeout', function ($window, $scope, $http, Upload, $timeout) {

	$scope.add_members = function (name, mobileno, email, address, designation, workexperience, joiningdate, salary ) {
        $http({
                method: "POST",
                url: ApiUrl + 'api_restostaff.php',
                data: {

					name: name,
                    mobileno: mobileno,
                    email: email,
                    address: address,
                    designation: designation,
                    workexperience: workexperience,
                    joiningdate: joiningdate,
                    salary: salary,
                    action: "add_members"
                },
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            })
            .success(function (data) {
                if (data.errors) {
                    $scope.message = "Something went wrong, please try again.";
                } else {
                    $scope.message = data.scalar;
                    if ($scope.message == "Success") {
                        $scope.fetch_all_members();
                        $scope.name = "";
                        $scope.mobileno = "";
                        $scope.email = "";
                        $scope.address = "";
                        $scope.designation = "";
                        $scope.workexperience = "";
                        $scope.joiningdate = "";
                        $scope.salary = "";
                        $("#restomember").modal("toggle");
                    } 
                    else{
                        alert($scope.message);
                    }
                }
            })
	} 

    $scope.fetch_all_member = function(){
        $http.get(ApiUrl+"api_restostaff.php?action=fetch_all_member")
        .success(function(allstaff){
            if(allstaff==null || allstaff==undefined || allstaff=="Invalid request"){
                $scope.allstaff = "";
            }
            else{
                $scope.allstaff = allstaff;
            }
        })
    }

    $scope.fetch_all_member();

}]);