tdipllp.controller('restaurantcontroller', ['$window', '$scope', '$http', 'Upload', '$timeout', function ($window, $scope, $http, Upload, $timeout) {
    $scope.add_food=function(){
        file.upload = Upload.upload({                  
            method: 'POST',
            url: ApiUrl+'api_media.php',
            data: { 
                foodname:foodname,
                category:category,
                file: file,
                price:price,
                action:"add_food",
            }                  
        }).then(function (resp) {
           
            alert("Data uploaded successfully")
            $scope.foodname = "";
            $scope.category = "";
            $scope.price = "";
            $('#fooditem').modal('toggle');
            $scope.fetch_all_foods();
            

        }); 

        file.upload.then(function (resp) {
            $timeout(function () {
                file.result = resp;
            });
        }, function (resp) {
            alert("something went wrong please try again.");
        }, function (evt) {
            file.progress = Math.min(100, parseInt(100.0 * evt.loaded / evt.total));
        });
    }
	

    $scope.fetch_all_foods = function(){
        $http.get(ApiUrl+"api_restaurant.php?action=fetch_all_foods")
        .success(function(allfoods){
            if(allfoods==null || allfoods==undefined || allfoods=="Invalid request"){
                $scope.allfoods = "";
            }
            else{
                $scope.allfoods = allfoods;
            }
        })
    }

    $scope.fetch_all_foods();

}]);