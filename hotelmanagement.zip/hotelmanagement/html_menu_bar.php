<div class="">
		<div class="menubar">

			<div class=" text-white"><br><br>
				<h2>Hotel Master</h2>
				<hr><br>
				<span ><a href="<?php echo $baseurl;?>Dashboard" style=" text-decoration: none;">Dashboard &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; <i class="fa fa-home" aria-hidden="true"></i></a> </span><br><br>

        		
				<!-- <span class="drop-down menu"><a href="<?php echo $baseurl;?>User_Management" style="color: white; text-decoration: none;"> User Management&emsp;&emsp;&emsp;&emsp;<i class="fa fa-angle-right" aria-hidden="true"></i></a>
                
				</span><br><br>
				<span>
					<a href="<?php echo $baseurl;?>Create_facilities"style="color: white; text-decoration: none;"> Create Facilities&emsp;&emsp;&emsp;&emsp;&emsp;<i class="fa fa-th" aria-hidden="true"></i></a></span><br><br>
				<span>
					<a href="<?php echo $baseurl;?>Rooms"style="color: white; text-decoration: none;"> Rooms&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;<i class="fa fa-eye-slash" aria-hidden="true"></i></a></span><br><br>
				<span>
					<a href="<?php echo $baseurl;?>Booking"style="color: white; text-decoration: none;"> Booking&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<i class="fa fa-bell" aria-hidden="true"></i></a></span><br><br>
				<span>
					<a href="<?php echo $baseurl;?>Find_Room"style="color: white; text-decoration: none;"> Find room&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<i class="fa fa-plus" aria-hidden="true"></i></a></span><br><br>
				<span>
					<a href="<?php echo $baseurl;?>Restaurant"style="color: white; text-decoration: none;"> Restaurant&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<i class="fa fa-cutlery" aria-hidden="true"></i></a></span><br><br>
				<span>
					<a href="<?php echo $baseurl;?>Restaurant_Staff"style="color: white; text-decoration: none;">Restaurant Staff&emsp;&emsp;&emsp;&emsp;&ensp;<i class="fa fa-book" aria-hidden="true"></i></span></a><br><br> -->
				<span>
					<a href="<?php echo $baseurl;?>Room_order"style="color: white; text-decoration: none;">Room Order&emsp;&emsp;&emsp;&emsp;&ensp;<i class="fa fa-book" aria-hidden="true"></i></span></a><br><br>
				<!-- <span>
					<a href="<?php echo $baseurl;?>Room_checkout"style="color: white; text-decoration: none;">Room Checkout&emsp;&emsp;&emsp;&emsp;&ensp;<i class="fa fa-book" aria-hidden="true"></i></span></a><br><br> -->
				<span>
					<script src="<?php echo $baseurl; ?>jscontroller/login.js"></script>
					<div class="" ng-controller="logincontroller" ng-cloak>
						<button class="btn btn-dark btn-sm" type="submit" ng-click="logout()" style=""><i class="fa fa-power-off" aria-hidden="true"></i></button>
				    </div>

			</div>
			
		</div>
	</div>



