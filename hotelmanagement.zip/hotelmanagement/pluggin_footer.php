<!-- Vendor js -->
<!-- <script src="<?php echo $baseurl;?>assets/js/vendor.min.js"></script> -->

<!-- optional plugins -->
<!-- <script src="<?php echo $baseurl;?>assets/libs/moment/moment.min.js"></script> -->
<!-- <script src="<?php echo $baseurl;?>assets/libs/apexcharts/apexcharts.min.js"></script> -->
<!-- <script src="<?php echo $baseurl;?>assets/libs/flatpickr/flatpickr.min.js"></script> -->

<!-- page js -->
<!-- <script src="<?php echo $baseurl;?>assets/js/pages/dashboard.init.js"></script> -->

<!-- App js -->
<!-- <script src="<?php echo $baseurl;?>assets/js/app.min.js"></script> -->
<script src="https://code.jquery.com/jquery-3.6.3.js"></script>

<!-- mutliselect -->

<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script> -->
