<?php
    header('Access-Control-Allow-Origi: *');
    ob_start("ob_gzhandler");
    error_reporting(1);
    date_default_timezone_set("Asia/Kolkata");
    session_start();

    //config Files
	include_once 'Config/db_config.php';
	include_once 'Config/general_config.php';
	include_once 'Controller/td_controller.php';

	// worker
	include_once 'Controller/controller_login.php';
	include_once 'Controller/controller_dashboard.php';
	include_once 'Controller/controller_worker.php';
	include_once 'Controller/controller_restostaff.php';
	include_once 'Controller/controller_roomorder.php';
	include_once 'Controller/controller_registeration.php';
	include_once 'Controller/controller_facilities.php';
	include_once 'Controller/controller_rooms.php';
	include_once 'Controller/controller_restaurant.php';
	include_once 'Controller/controller_roommaster.php';
	include_once 'Controller/controller_companiesmaster.php';
	include_once 'Controller/controller_session_master.php';
	include_once 'Controller/controller_designationmaster.php';
	include_once 'Controller/controller_unitmaster.php';
	include_once 'Controller/controller_occupymaster.php';
	include_once 'Controller/controller_roomcategorymaster.php';
	include_once 'Controller/controller_menucategorymaster.php';
	include_once 'Controller/controller_menuitemmaster.php';
	include_once 'Controller/controller_tablemaster.php';
	include_once 'Controller/controller_customermaster.php';
	include_once 'Controller/controller_employeemaster.php';
	include_once 'Controller/controller_checkout.php';
	// include_once 'Controller/controller_media.php';

	// worker object
	$login = new logincontroller($db);
	$worker = new workercontroller($db);
	$restaurant_staff = new restostaffcontroller($db);
	$registeration = new registerationcontroller($db);
	$roomorder = new roomordercontroller($db);
	$roommaster = new roommastercontroller($db);
	$session_master = new session_mastercontroller($db);
	$restaurant = new restaurantcontroller($db);
	$facilities = new facilitiescontroller($db);
	$rooms = new roomscontroller($db);
	$tdcont = new universalController($db);
	$designationmaster = new designationmastercontroller($db);
	$unitmaster = new unitmastercontroller($db);
	$occupymaster = new occupymastercontroller($db);
	$roomcategorymaster = new roomcategorymastercontroller($db);
	$menucategorymaster = new menucategorymastercontroller($db);
	$menuitemmaster = new menuitemmastercontroller($db);
	$tablemaster = new tablemastercontroller($db);
	$customermaster = new customermastercontroller($db);
	$employeemaster = new employeemastercontroller($db);
	$companiesmaster = new companiesmastercontroller($db);
	$roomdashboard = new dashboardcontroller($db);
	$checkout = new checkoutcontroller($db);
	// if(isset($_SESSION['userslug'])){

	// 	$userslug = $_SESSION['userslug'];
	// }

?>