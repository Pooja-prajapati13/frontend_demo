<?php  
session_start();

	include_once 'td_includes.php';
	// if(!isset($_SESSION['userslug'])){
	// 	header("location:".'loginn.php');
	// }
?>

<!DOCTYPE html>
<html>
<head>
	<?php
			 
				
			
			include_once 'html_title.php';
			include_once 'pluggin_header.php';
			
		?>
	<!-- <title></title> -->
</head>
<body class="text-left" ng-app="tdipllp">
		<div id="wrapper">
			<?php
				// include_once 'html_header.php';
			// if ( $_GET['page']!='login'){
				
			
				
			// 	}
				
				if ($_GET['page']=='login') {
					include_once 'View/loginn.php';
				}
				
				if($_SESSION['id']!='')
				{

					include_once 'html_menu_bar.php';
				   include_once 'navbar.php';
}
				if ($_GET['page']=="" || $_GET['page']=='Dashboard') {
					include_once 'View/dashboard.php';
				}	
				else if ($_GET['page']=='User_Management') {
					include_once 'View/worker.php';
				}
				else if ($_GET['page']=='Registeration') {
					include_once 'View/registeration.php';
				}
				else if ($_GET['page']=='Room_order') {
					include_once 'View/roomorder.php';
				}
				else if ($_GET['page']=='Room_master') {
					include_once 'View/roommaster.php';
				}
				else if ($_GET['page']=='Session_master') {
					include_once 'View/session_master.php';
				}
				else if ($_GET['page']=='Companies_master') {
					include_once 'View/companiesmaster.php';
				}
				else if ($_GET['page']=='Designation_master') {
					include_once 'View/designationmaster.php';
				}
				else if ($_GET['page']=='Unit_master') {
					include_once 'View/unitmaster.php';
				}
				else if ($_GET['page']=='Occupy_master') {
					include_once 'View/occupymaster.php';
				}
				else if ($_GET['page']=='Room_category_master') {
					include_once 'View/roomcategorymaster.php';
				}
				else if ($_GET['page']=='Menu_category_master') {
					include_once 'View/menucategorymaster.php';
				}
				else if ($_GET['page']=='Menu_item_master') {
					include_once 'View/menuitemmaster.php';
				}
				else if ($_GET['page']=='Table_master') {
					include_once 'View/tablemaster.php';
				}
				else if ($_GET['page']=='Customer_master') {
					include_once 'View/customermaster.php';
				}
				else if ($_GET['page']=='Employee_master') {
					include_once 'View/employeemaster.php';
				}
				else if ($_GET['page']=='Room_checkout') {
					include_once 'View/checkout.php';
				}
				else if ($_GET['page']=='Create_facilities') {
					include_once 'View/facilities.php';
				}

				else if ($_GET['page']=='Rooms') {
					include_once 'View/rooms.php';
				}
				else if ($_GET['page']=='Booking') {
					include_once 'View/booking.php';
				}
				else if ($_GET['page']=='Find_Room') {
					include_once 'View/availability.php';
				}
				else if ($_GET['page']=='Restaurant') {
					include_once 'View/restaurant.php';
				}
				else if ($_GET['page']=='Restaurant_Staff') {
					include_once 'View/restostaff.php';
				}

				

				// else if ($_GET['page']=='signout') {
				// 	unset($_SESSION['userslug']);
				// 	header("location:".$baseurl.'login.php');
				// }

				include_once 'pluggin_footer.php';

			?>
		</div>
	</body>

</html>