
<!-- <link rel="shortcut icon" href="<?php echo $baseurl;?>assets/images/favicon.ico"> -->

<!-- plugins -->
<!-- <link href="<?php echo $baseurl;?>assets/libs/flatpickr/flatpickr.min.css" rel="stylesheet" type="text/css" /> -->

<!-- App css -->
<!-- <link href="<?php echo $baseurl;?>assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" /> -->
<!-- <link href="<?php echo $baseurl;?>assets/css/icons.min.css" rel="stylesheet" type="text/css" /> -->
<!-- <link href="<?php echo $baseurl;?>assets/css/app.min.css" rel="stylesheet" type="text/css" /> -->

<script src="<?php echo $baseurl;?>angular/core/angular.js"></script>
<script type="text/javascript" src="<?php echo $baseurl;?>angular/core/angular-sanitize.min.js"></script>
<script src="<?php echo $baseurl;?>angular/core/angular-resource.js"></script>
<script src="<?php echo $baseurl;?>angular/core/angular-route.js"></script>
<script src="<?php echo $baseurl;?>angular/core/angular-animate.js"></script>
<script src="<?php echo $baseurl;?>angular/core/ng-file-upload.js"></script>
<script src="<?php echo $baseurl;?>angular/core/angular-ui-bootstrap.js"></script>
<script src="<?php echo $baseurl;?>angular/core/to_Array_filters.js"></script>
<script src="<?php echo $baseurl;?>angular/app.js"></script>
<script src="<?php echo $baseurl;?>angular/core/ng-tags-input.js"></script>

<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.5.0/angular.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.5.0/angular-sanitize.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/angular-ui-select/0.19.8/select.js"></script>
<!-- <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.css"> -->

<!-- angular select -->
<!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/3.4.5/select2.css"> -->
<!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/angular-ui-select/0.19.8/select.css"> -->



 <!-- my links -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" integrity="sha512-5A8nwdMOWrSz20fDsjczgUidUBR8liPYU+WymTZP1lmY9G6Oc7HlZv156XqnsgNUzTyMefFTcsFH/tnJE/+xBg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"/>	
<link rel="stylesheet" type="text/css" href="style.css">

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<!-- <link href="https://raw.githack.com/ttskch/select2-bootstrap4-theme/master/dist/select2-bootstrap4.css" rel="stylesheet"> -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>


<!-- customer  -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">


  <!-- select2 -->
  <!-- <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" /> -->

  <!-- select2-bootstrap4-theme -->
  <!-- <link href="https://raw.githack.com/ttskch/select2-bootstrap4-theme/master/dist/select2-bootstrap4.css" rel="stylesheet">  -->
  <!-- <link href="select2-bootstrap4.css" rel="stylesheet">  -->





