<?php
	class facilitiescontroller
	{
		
		public function __construct($db)
		{
			$this->db = $db;
		}

		public function fetch_all_facilities(){
			$query = mysqli_query($this->db,"SELECT slug, facilitiesname,facility,description FROM facilities")OR die(mysqli_error($this->db));
			while ($row = mysqli_fetch_array($query,MYSQLI_ASSOC)) {
				$data[] = $row;
			}
			return $data;
		}

		public function delete_all_facilities($slug){
			$query = mysqli_query($this->db,"DELETE FROM facilities WHERE slug='$slug' ")OR die(mysqli_error($this->db));
			if ($query ) {
				return true;
			}
			
		}

		public function save_facilities($facilitiesname,$facility,$description,$slug){
			$query = mysqli_query($this->db,"INSERT INTO facilities(facilitiesname,facility,description,slug) VALUES ('$facilitiesname','$facility','$description','$slug') ")or die(mysqli_error($this->db));
			if($query){
				return true;
			}
		}

		
	}

?>