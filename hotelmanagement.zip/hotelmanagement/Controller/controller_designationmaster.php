<?php
	class designationmastercontroller
	{
		
		public function __construct($db)
		{
			$this->db = $db;
		}

		

		public function save_designation($designation_name,$designation_status){
			$query = mysqli_query($this->db,"INSERT INTO  designation_master(id,designation_name, designation_status) VALUES ('$id','$designation_name','$designation_status') ")or die(mysqli_error($this->db));
			if($query){
				return true;
			}
		}
		public function fetch_all_designation(){
			$query = mysqli_query($this->db,"SELECT id,designation_name, designation_status FROM designation_master")OR die(mysqli_error($this->db));
			while ($row = mysqli_fetch_array($query,MYSQLI_ASSOC)) {
				$data[] = $row;
			}
			return $data;
		}

		public function fetch_designation_detail($id){
			$query = mysqli_query($this->db,"SELECT designation_name, designation_status FROM designation_master WHERE id='$id'") OR die(mysqli_error($this->db));
			 $row = mysqli_fetch_array($query,MYSQLI_ASSOC);
			
			return $row;
		}

		//start designation update


		public function update_designation($id,$designation_name,$designation_status){
			
			$query = mysqli_query($this->db,"UPDATE designation_master SET designation_name='$designation_name', designation_status='$designation_status' WHERE id='$id'")  or die(mysqli_error($this->db));
			if ($query ) {
				return true;
			}
			
		}

		public function delete_designation($id){
			$query = mysqli_query($this->db,"DELETE FROM designation_master WHERE id='$id' ")OR die(mysqli_error($this->db));
			if ($query ) {
				return true;
			}
			
		}
		// public function fetch_customer_detail($slug){
		// 	$query = mysqli_query($this->db,"SELECT * FROM customer WHERE slug='$slug'")OR die(mysqli_error($this->db));
		// 	$row = mysqli_fetch_array($query,MYSQLI_ASSOC);
			
		// 	return $row;
		// }
		// public function detail_customer_modal($slug){
		// 	$query = mysqli_query($this->db,"SELECT code,status,bookingtime,checkin,checkout,adultno,childno,infantno,designation,designationfacilities,yourbudget,meals,bedpreference,guestname,company,email,phone,specialrequirement,address,city,country,state,postcode,roomtotal,discount,totalamount,servicetotal,tax,paid,nettotal,taxtotal,balance FROM room WHERE slug='$slug'") OR die(mysqli_error($this->db));
		// 	 $row = mysqli_fetch_array($query,MYSQLI_ASSOC);
			
		// 	return $row;
		// }

		// public function delete_customer($slug){
		// 	$query = mysqli_query($this->db,"DELETE FROM customer WHERE slug='$slug' ")OR die(mysqli_error($this->db));
		// 	if ($query ) {
		// 		return true;
		// 	}
			
		// public function get_max_id(){
		// 	$query = mysqli_query($this->db,"SELECT  MAX(id) AS max_id FROM registeration")OR die(mysqli_error($this->db));
		// 	while ($row = mysqli_fetch_array($query,MYSQLI_ASSOC)) {
		// 		$data = $row;
		// 	}
		// 	return $data['max_id'];
		
		// } 
		
		// public function registration_number(){
		// 	$query = mysqli_query($this->db,"SELECT registeration_no from registeration order by id desc limit 1")OR die(mysqli_error($this->db));
		// 	while ($row = mysqli_fetch_array($query,MYSQLI_ASSOC)){
		// 		$registration_number = $row['registration_number']+1 ;
		// 	}
			
		// } 

		
	}

?>