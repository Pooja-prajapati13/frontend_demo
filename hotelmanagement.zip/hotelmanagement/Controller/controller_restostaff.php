<?php
	class restostaffcontroller
	{
		
		public function __construct($db)
		{
			$this->db = $db;
		}

		public function fetch_all_resto_member(){
			$query = mysqli_query($this->db,"SELECT name,mobile,email,address,designation,workexperience,joiningdate,salary FROM restaurant_stafff")OR die(mysqli_error($this->db));
			while ($row = mysqli_fetch_array($query,MYSQLI_ASSOC)) {
				$data[] = $row;
			}
			return $data;
		}

		public function add_members($name,$mobileno,$email,$address,$designation,$workexperience,$joiningdate,$salary){
			$query = mysqli_query($this->db,"INSERT INTO restaurant_stafff(name,mobile,email,address,designation,workexperience,joiningdate,salary) VALUES ('$name','$mobileno','$email','$address','$designation','$workexperience','$joiningdate','$salary') ")or die(mysqli_error($this->db));
			if($query){
				return true;
			}
		}
	}

?>