<?php
	class workercontroller
	{
		
		public function __construct($db)
		{
			$this->db = $db;
		}

		public function fetch_all_members(){
			$query = mysqli_query($this->db,"SELECT slug,name,mobile,email,address,designation,workexperience,joiningdate,salary FROM hotel_staff")OR die(mysqli_error($this->db));
			while ($row = mysqli_fetch_array($query,MYSQLI_ASSOC)) {
				$data[] = $row;
			}
			return $data;
		}
		
		public function add_member($name,$mobileno,$email,$address,$designation,$workexperience,$joiningdate,$salary,$slug){
			$query = mysqli_query($this->db,"INSERT INTO hotel_staff (name,mobile,email,address,designation,workexperience,joiningdate,salary,slug) VALUES ('$name','$mobileno','$email','$address','$designation','$workexperience','$joiningdate','$salary','$slug') ")or die(mysqli_error($this->db));
			if($query){
				return true;
			}
		}
	}

?>