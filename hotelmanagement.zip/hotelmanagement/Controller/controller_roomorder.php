<?php
	class roomordercontroller
	{
		
		public function __construct($db)
		{
			$this->db = $db;
		}

		public function fetch_all_order($registeration_no){
			$query = mysqli_query($this->db,"SELECT service,rate,quantity,total,is_free FROM room_order WHERE registration_number='$registeration_no'")OR die(mysqli_error($this->db));
			while ($row = mysqli_fetch_array($query,MYSQLI_ASSOC)) {
				$data[] = $row;
			}
			return $data;
		}

		// public function registration_number($id){
		// 	$query = mysqli_query($this->db,"SELECT registration_no from registration WHERE id='$id'") OR die(mysqli_error($this->db));
		// 	$row = mysqli_fetch_array($query, MYSQLI_ASSOC);
			
		// 	return $row;
		// 	}

		// public function fetch_registration_number($id){
		// 	$query = mysqli_query($this->db,"SELECT registration_no from registration WHERE id='$id'") OR die(mysqli_error($this->db));
		// 	 $row = mysqli_fetch_array($query,MYSQLI_ASSOC);
			
		// 	return $row;
		// }
		

		// public function fetch_customer_detail($slug){
		// 	$query = mysqli_query($this->db,"SELECT * FROM customer WHERE slug='$slug'")OR die(mysqli_error($this->db));
		// 	$row = mysqli_fetch_array($query,MYSQLI_ASSOC);
			
		// 	return $row;
		// }
		// public function detail_customer_modal($slug){
		// 	$query = mysqli_query($this->db,"SELECT code,status,bookingtime,checkin,checkout,adultno,childno,infantno,room,roomfacilities,yourbudget,meals,bedpreference,guestname,company,email,phone,specialrequirement,address,city,country,state,postcode,roomtotal,discount,totalamount,servicetotal,tax,paid,nettotal,taxtotal,balance FROM room WHERE slug='$slug'") OR die(mysqli_error($this->db));
		// 	 $row = mysqli_fetch_array($query,MYSQLI_ASSOC);
			
		// 	return $row;
		// }

		// public function delete_customer($slug){
		// 	$query = mysqli_query($this->db,"DELETE FROM customer WHERE slug='$slug' ")OR die(mysqli_error($this->db));
		// 	if ($query ) {
		// 		return true;
		// 	}
			
		// }

		public function add_order($service,$rate,$quantity,$total,$is_free,$slug){
			$query = mysqli_query($this->db,"INSERT INTO  room_order(registration_number,service, rate, quantity, total, is_free) VALUES ('$slug','$service','$rate','$quantity','$total','$is_free') ")or die(mysqli_error($this->db));
			if($query){
				return true;
			}
		}
	}

?>