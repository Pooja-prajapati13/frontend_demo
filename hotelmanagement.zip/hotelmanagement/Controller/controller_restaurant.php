<?php
	class restaurantcontroller
	{
		
		public function __construct($db)
		{
			$this->db = $db;
		}
		public function add_food($foodname,$category,$file,$price,$slug){
		$query = mysqli_query($this->db,"INSERT INTO restaurant(foodname,category,image,price,slug) VALUES(N'$foodname',N'$category',N'$file',N'$price',N'$slug') ")or die(mysqli_error($this->db));

		if($query){
			return true;

		}	
	}
		public function fetch_all_foods(){
			$query = mysqli_query($this->db,"SELECT foodname,category,image,price FROM restaurant")OR die(mysqli_error($this->db));
			while ($row = mysqli_fetch_array($query,MYSQLI_ASSOC)) {
				$data[] = $row;
			}
			return $data;
		}

		
	}

?>