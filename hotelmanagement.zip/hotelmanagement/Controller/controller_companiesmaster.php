<?php
	class companiesmastercontroller
	{
		
		public function __construct($db)
		{
			$this->db = $db;
		}

		

		public function save_companies($companyname,$phone,$mobile,$email,$address,$gst){
			$query = mysqli_query($this->db,"INSERT INTO  companies_master(companyname,phone,mobile,email,address,gst) VALUES ('$companyname','$phone','$mobile','$email','$address','$gst') ")or die(mysqli_error($this->db));
			if($query){
				return true;
			}
		}
		public function fetch_all_companies(){
			$query = mysqli_query($this->db,"SELECT id,companyname,phone,mobile,email,address,gst FROM companies_master")OR die(mysqli_error($this->db));
			while ($row = mysqli_fetch_array($query,MYSQLI_ASSOC)) {
				$data[] = $row;
			}
			return $data;
		}

		public function fetch_companies_detail($id){
			$query = mysqli_query($this->db,"SELECT companyname,phone,mobile,email,address,gst FROM companies_master WHERE id='$id'") OR die(mysqli_error($this->db));
			 $row = mysqli_fetch_array($query,MYSQLI_ASSOC);
			
			return $row;
		}

		//start companies update


		public function update_companies($id,$companyname,$phone,$mobile,$email,$address,$gst){
			
			$query = mysqli_query($this->db,"UPDATE companies_master SET companyname='$companyname', phone='$phone',mobile='$mobile', email='$email',address='$address', gst='$gst' WHERE id='$id'")  or die(mysqli_error($this->db));
			if ($query ) {
				return true;
			}
			
		}

		public function delete_companies($id){
			
			$query = mysqli_query($this->db,"DELETE FROM companies_master WHERE id='$id' ")OR die(mysqli_error($this->db));
			if ($query ) {
				return true;
			}
			
		}
		

		
	}

?>