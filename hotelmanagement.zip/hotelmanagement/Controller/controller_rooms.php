<?php
	class roomscontroller
	{
		
		public function __construct($db)
		{
			$this->db = $db;
		}

		public function fetch_all_rooms(){
			$query = mysqli_query($this->db,"SELECT slug, roomno, floor, type, price FROM room")OR die(mysqli_error($this->db));
			while ($row = mysqli_fetch_array($query,MYSQLI_ASSOC)) {
				$data[] = $row;
			}
			return $data;
		}

		public function add_image($slug,$roomslug,$file){
		$query = mysqli_query($this->db,"INSERT INTO roomimage(slug,roomslug,imagename) VALUES(N'$slug',N'$roomslug',N'$file') ")or die(mysqli_error($this->db));

		if($query){
			return true;

		}	
	}

		public function delete_all_rooms($slug){
			$query = mysqli_query($this->db,"DELETE FROM room WHERE slug='$slug' ")OR die(mysqli_error($this->db));
			if ($query ) {
				return true;
			}
			
		}

		public function fetch_room_detail($slug){
			$query = mysqli_query($this->db,"SELECT roomno, floor, type, price FROM room WHERE slug='$slug'") OR die(mysqli_error($this->db));
			 $row = mysqli_fetch_array($query,MYSQLI_ASSOC);
			
			return $row;
		}

		public function fetch_image($slug){
			$query = mysqli_query($this->db,"SELECT slug,roomslug,imagename FROM roomimage WHERE roomslug='$slug'") OR die(mysqli_error($this->db));
			 while ($row = mysqli_fetch_array($query,MYSQLI_ASSOC)) {
				$data[] = $row;
			}
			return $data;
		}

		public function fetch_facilities($type){
			$query = mysqli_query($this->db,"SELECT facility,description FROM facilities WHERE facilitiesname='$type' ")or die(mysqli_error($this->db));
			while ($row = mysqli_fetch_array($query,MYSQLI_ASSOC)) {
				$data[] = $row;
			}
			return $data;
		}


		public function update_room_detail($slug,$roomno,$floor,$type,$price){
			$query = mysqli_query($this->db,"UPDATE room SET roomno='$roomno', floor='$floor', type='$type', price='$price' WHERE slug='$slug'")  or die(mysqli_error($this->db));
			if ($query ) {
				return true;
			}
			
		}

		public function save_rooms($roomno,$floor,$type,$price,$slug){
			$query = mysqli_query($this->db,"INSERT INTO room(roomno, floor, type, price, slug) VALUES (N'$roomno',N'$floor',N'$type',N'$price',N'$slug') ")or die(mysqli_error($this->db));
			if($query){
				return true;
			}
		}
	}

?>
