<?php
session_start();
	class logincontroller
	{
		
		public function __construct($db)
		{
			$this->db = $db;
		}


		public function save_login($userid, $password) {
			$pwd = md5($password);
    $query = mysqli_query($this->db, "SELECT * FROM login WHERE userid = '$userid' AND password = '$pwd'") or die(mysqli_error($this->db));

    $row = mysqli_fetch_assoc($query);

    if (count($row)) {
        $_SESSION['id'] = $row['id'];
        $message = "Login Successful";
    } else {

        $message = "User id and password does not match.";
    }

    $json = json_encode($message);
    echo $json;
}
		
		public function logout(){
echo "hhde";
			 unset($_SESSION['id']);
			 echo "echo";
		}

		
	}

?>