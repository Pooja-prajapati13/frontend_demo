<?php
class universalController{
	private $db;

	public function __construct($db)
	{
		$this->db = $db;
	}

	

	public function getExtension($str) 
	{
	         $i = strrpos($str,".");
	         if (!$i) { return ""; } 

	         $l = strlen($str) - $i;
	         $ext = substr($str,$i+1,$l);
	         return $ext;
	}
	
	
	
	
}
?>