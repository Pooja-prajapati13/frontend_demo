<?php
	class dashboardcontroller
	{
		
		public function __construct($db)
		{
			$this->db = $db;
		}

		

		public function fetch_all_room_count(){
			$query = mysqli_query($this->db, "SELECT count(id) AS total FROM  room_master") or die(mysqli_error($this->db));

			$row = mysqli_fetch_array($query, MYSQLI_ASSOC);
			return $row['total']; 
		}

		public function fetch_all_room(){
        $query = mysqli_query($this->db, "SELECT * FROM room_master") or die(mysqli_error($this->db));

        while ($row = mysqli_fetch_array($query, MYSQLI_ASSOC)) {
           
            $data[] = $row;
        }
        return $data;
    	}


    	public function check_room($id){
        $query = mysqli_query($this->db, "SELECT * FROM `registeration` WHERE room_no=".$id." and status=0") or die(mysqli_error($this->db));

        while ($row = mysqli_fetch_array($query, MYSQLI_ASSOC)) {
           
            $data[] = $row;
        }
        return $data;
    	}


		// public function fetch_all_customer(){
		// 	$query = mysqli_query($this->db,"SELECT slug,guestname,email,phone,address,checkin,checkout FROM customer")OR die(mysqli_error($this->db));
		// 	while ($row = mysqli_fetch_array($query,MYSQLI_ASSOC)) {
		// 		$data[] = $row;
		// 	}
		// 	return $data;
		// }

		// public function fetch_customer_detail($slug){
		// 	$query = mysqli_query($this->db,"SELECT * FROM customer WHERE slug='$slug'")OR die(mysqli_error($this->db));
		// 	$row = mysqli_fetch_array($query,MYSQLI_ASSOC);
			
		// 	return $row;
		// }
		// public function detail_customer_modal($slug){
		// 	$query = mysqli_query($this->db,"SELECT code,status,bookingtime,checkin,checkout,adultno,childno,infantno,room,roomfacilities,yourbudget,meals,bedpreference,guestname,company,email,phone,specialrequirement,address,city,country,state,postcode,roomtotal,discount,totalamount,servicetotal,tax,paid,nettotal,taxtotal,balance FROM room WHERE slug='$slug'") OR die(mysqli_error($this->db));
		// 	 $row = mysqli_fetch_array($query,MYSQLI_ASSOC);
			
		// 	return $row;
		// }

		// public function delete_customer($slug){
		// 	$query = mysqli_query($this->db,"DELETE FROM customer WHERE slug='$slug' ")OR die(mysqli_error($this->db));
		// 	if ($query ) {
		// 		return true;
		// 	}
			
		// public function get_max_id(){
		// 	$query = mysqli_query($this->db,"SELECT  MAX(id) AS max_id FROM registeration")OR die(mysqli_error($this->db));
		// 	while ($row = mysqli_fetch_array($query,MYSQLI_ASSOC)) {
		// 		$data = $row;
		// 	}
		// 	return $data['max_id'];
		
		// } 
		
		// public function registration_number(){
		// 	$query = mysqli_query($this->db,"SELECT registeration_no from registeration order by id desc limit 1")OR die(mysqli_error($this->db));
		// 	while ($row = mysqli_fetch_array($query,MYSQLI_ASSOC)){
		// 		$registration_number = $row['registration_number']+1 ;
		// 	}
			
		// } 

		
	}

?>